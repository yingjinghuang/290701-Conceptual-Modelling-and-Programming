package at.ac.univie.gis.week7.canvas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Beyond pre-built components — here we draw our own canvas.
 *
 * Demonstrates the full interactive cycle:
 *   user click  ->  listener fires  ->  data updated  ->  repaint() called
 *                ->  Java calls paintComponent()  ->  screen refreshes.
 *
 * What this example shows:
 *   - extending JPanel and overriding paintComponent
 *   - casting Graphics to Graphics2D and enabling anti-aliasing
 *   - drawLine / fillOval primitives
 *   - MouseListener via MouseAdapter — a click adds a vertex
 *   - calling repaint() after the data changes
 *
 * Note: MouseAdapter is a convenience class that provides empty bodies for all
 * five MouseListener methods, so we only override the one we need. You CANNOT
 * replace it with a single-line lambda because MouseListener has five abstract
 * methods and a lambda can only implement an interface with one method.
 *
 * Things to play with:
 *   - Comment out the repaint() call inside mouseClicked() — clicks no longer
 *     show up until you resize the window. This is why repaint() matters.
 *   - Change DOT_RADIUS, the dot color, or the line color.
 *   - Add a right-click handler that removes the last point.
 */
public class CustomCanvasExample extends JPanel {

    private static final int DOT_RADIUS = 6;

    // The "model": our data lives in a simple list of points.
    // The view (paintComponent) only reads from this list.
    private final List<int[]> points = new ArrayList<>();

    public CustomCanvasExample() {
        setPreferredSize(new Dimension(600, 500));
        setBackground(Color.WHITE);

        // Register a MouseListener on this panel so we hear about clicks.
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // 1. Update the data: store the click location.
                points.add(new int[]{e.getX(), e.getY()});
                // 2. Request a redraw — Java will call paintComponent() soon.
                repaint();
            }
        });
    }

    /**
     * IMPORTANT: never call this method yourself. Java calls it whenever the
     * panel needs to be (re)drawn. Each call wipes the canvas via
     * super.paintComponent() and redraws everything from the current data.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // "Upgrade" the brush to Graphics2D so we get anti-aliasing
        // (smooth, non-jagged edges).
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);

        // Connect consecutive points with line segments.
        g2d.setColor(Color.BLUE);
        for (int i = 1; i < points.size(); i++) {
            int[] a = points.get(i - 1);
            int[] b = points.get(i);
            g2d.drawLine(a[0], a[1], b[0], b[1]);
        }

        // Then draw a red dot at each clicked location.
        g2d.setColor(Color.RED);
        for (int[] p : points) {
            g2d.fillOval(p[0] - DOT_RADIUS, p[1] - DOT_RADIUS,
                         DOT_RADIUS * 2, DOT_RADIUS * 2);
        }

        // Small hint text drawn on the canvas itself.
        g2d.setColor(Color.DARK_GRAY);
        g2d.drawString("Click anywhere to add a vertex. Points: " + points.size(),
                       10, 20);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Custom Canvas: click to draw");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        CustomCanvasExample canvas = new CustomCanvasExample();

        // A small control bar with a Clear button (lambda style).
        JButton clear = new JButton("Clear");
        clear.addActionListener(e -> {
            canvas.points.clear();
            canvas.repaint();
        });

        JPanel controls = new JPanel();
        controls.add(clear);

        // BorderLayout puts the controls at the bottom (SOUTH) and the
        // drawing canvas in the middle (CENTER).
        frame.setLayout(new BorderLayout());
        frame.add(canvas, BorderLayout.CENTER);
        frame.add(controls, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }
}
