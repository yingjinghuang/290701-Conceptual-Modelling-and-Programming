package at.ac.univie.gis.week7.geosnap;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * World-coordinate drawing plus buffer snapping.
 *
 * This example combines three of the trickier GUI ideas:
 *
 *   1. The screen / world coordinate MISMATCH. The screen origin sits at the
 *      top-left and the Y axis points DOWN, but our spatial data uses a normal
 *      Y-up coordinate system with the origin at the bottom-left.
 *
 *   2. AffineTransform bridges the two. We configure the transform once and
 *      then draw using world coordinates directly. The inverse transform
 *      converts mouse clicks (screen coordinates) back into world coordinates.
 *
 *   3. Buffer snapping. A click that lands close enough to the very first
 *      vertex snaps onto it exactly, producing a clean, topologically closed
 *      polygon instead of a frustrating tiny gap.
 *
 * The "world" here is a 100 x 100 unit square with the origin at the
 * bottom-left and Y pointing up. Click inside the panel to add vertices.
 * When your click falls within SNAP_TOLERANCE_PIXELS of the first vertex,
 * the polygon snaps closed and is filled.
 *
 * Things to play with:
 *   - Change WORLD_SIZE or the panel size and watch the transform adapt.
 *   - Print mouseEvent.getX/Y() AND the world coordinates inside mouseClicked
 *     to see the conversion in action.
 *   - Tighten SNAP_TOLERANCE_PIXELS to 2 and try to close the polygon — this
 *     is how frustrating digitising without snapping feels.
 */
public class GeoSnapExample extends JPanel {

    private static final double WORLD_SIZE = 100.0;
    private static final double SNAP_TOLERANCE_PIXELS = 12.0;
    private static final int VERTEX_RADIUS_PIXELS = 5;

    /** Polygon vertices in WORLD coordinates (Y points up). */
    private final List<Point2D.Double> vertices = new ArrayList<>();
    private boolean closed = false;

    private final JLabel statusLabel;

    public GeoSnapExample(JLabel statusLabel) {
        this.statusLabel = statusLabel;
        setPreferredSize(new Dimension(600, 600));
        setBackground(Color.WHITE);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleClick(e.getX(), e.getY());
            }
        });
    }

    /**
     * Build the world -> screen transform in three operations:
     *   1. translate the origin down to the bottom edge of the panel
     *   2. scale so WORLD_SIZE units fit the panel
     *   3. flip the Y axis (negative scale on Y) so world-Y goes up on screen
     *
     * Note that AffineTransform operations are applied in REVERSE order to the
     * point — the last call here happens first when the transform is applied.
     */
    private AffineTransform worldToScreen() {
        double scaleX = getWidth()  / WORLD_SIZE;
        double scaleY = getHeight() / WORLD_SIZE;
        double scale = Math.min(scaleX, scaleY); // uniform scaling, no distortion

        AffineTransform t = new AffineTransform();
        t.translate(0, getHeight());      // 1) move origin to bottom-left
        t.scale(scale, -scale);           // 2) & 3) scale + flip Y
        return t;
    }

    private void handleClick(int screenX, int screenY) {
        if (closed) {
            return; // polygon already closed; ignore further clicks
        }

        // Buffer-snap check is done in SCREEN space because the tolerance
        // is expressed in pixels — that's what the user actually sees.
        // We only allow closing once we have at least 3 vertices (a triangle).
        if (vertices.size() >= 3) {
            Point2D.Double firstScreen = worldToScreenPoint(vertices.get(0));
            double dx = firstScreen.x - screenX;
            double dy = firstScreen.y - screenY;
            if (Math.hypot(dx, dy) <= SNAP_TOLERANCE_PIXELS) {
                closed = true;
                statusLabel.setText("Polygon closed with " + vertices.size() + " vertices.");
                repaint();
                return;
            }
        }

        // Otherwise convert the screen click back into world coordinates and
        // add a new vertex. This is the inverse of worldToScreen().
        try {
            Point2D world = worldToScreen().inverseTransform(
                    new Point2D.Double(screenX, screenY), null);
            vertices.add(new Point2D.Double(world.getX(), world.getY()));
            statusLabel.setText(String.format(
                    "Added vertex %d at world (%.2f, %.2f).",
                    vertices.size(), world.getX(), world.getY()));
            repaint();
        } catch (NoninvertibleTransformException ex) {
            // Cannot happen for a uniform scale + translate. If it did, we
            // would simply ignore the click.
        }
    }

    /** Convert a single world-space point into screen coordinates. */
    private Point2D.Double worldToScreenPoint(Point2D.Double world) {
        Point2D out = worldToScreen().transform(world, null);
        return new Point2D.Double(out.getX(), out.getY());
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw a faint grid so the Y-up world coordinate system is visible.
        drawWorldGrid(g2d);

        if (vertices.isEmpty()) {
            return;
        }

        // Build a Polygon in screen coordinates because java.awt.Polygon
        // only stores integer pixel positions.
        Polygon screenPoly = new Polygon();
        for (Point2D.Double v : vertices) {
            Point2D.Double s = worldToScreenPoint(v);
            screenPoly.addPoint((int) Math.round(s.x), (int) Math.round(s.y));
        }

        if (closed) {
            // Filled polygon with a translucent blue interior and a darker outline.
            g2d.setColor(new Color(80, 160, 220, 120));
            g2d.fillPolygon(screenPoly);
            g2d.setColor(new Color(20, 80, 140));
            g2d.drawPolygon(screenPoly);
        } else {
            // Open polyline so far — draw the segments we already have.
            g2d.setColor(Color.BLUE);
            for (int i = 1; i < screenPoly.npoints; i++) {
                g2d.drawLine(screenPoly.xpoints[i - 1], screenPoly.ypoints[i - 1],
                             screenPoly.xpoints[i],     screenPoly.ypoints[i]);
            }

            // Once we have enough points to close, draw a green ring around the
            // first vertex to show the snap target.
            if (vertices.size() >= 3) {
                int sx = screenPoly.xpoints[0];
                int sy = screenPoly.ypoints[0];
                int r  = (int) SNAP_TOLERANCE_PIXELS;
                g2d.setColor(new Color(0, 160, 0));
                g2d.drawOval(sx - r, sy - r, r * 2, r * 2);
            }
        }

        // Draw vertex dots on top so they stay visible above the fill.
        g2d.setColor(Color.RED);
        for (int i = 0; i < screenPoly.npoints; i++) {
            g2d.fillOval(screenPoly.xpoints[i] - VERTEX_RADIUS_PIXELS,
                         screenPoly.ypoints[i] - VERTEX_RADIUS_PIXELS,
                         VERTEX_RADIUS_PIXELS * 2,
                         VERTEX_RADIUS_PIXELS * 2);
        }
    }

    /** Draws a 10-unit grid in world coordinates so the transform is visible. */
    private void drawWorldGrid(Graphics2D g2d) {
        g2d.setColor(new Color(230, 230, 230));
        for (double w = 0; w <= WORLD_SIZE; w += 10) {
            // Vertical grid lines at world x = w.
            Point2D.Double a = worldToScreenPoint(new Point2D.Double(w, 0));
            Point2D.Double b = worldToScreenPoint(new Point2D.Double(w, WORLD_SIZE));
            g2d.drawLine((int) a.x, (int) a.y, (int) b.x, (int) b.y);

            // Horizontal grid lines at world y = w.
            Point2D.Double c = worldToScreenPoint(new Point2D.Double(0, w));
            Point2D.Double d = worldToScreenPoint(new Point2D.Double(WORLD_SIZE, w));
            g2d.drawLine((int) c.x, (int) c.y, (int) d.x, (int) d.y);
        }

        // Origin marker — bottom-left in world space.
        Point2D.Double origin = worldToScreenPoint(new Point2D.Double(0, 0));
        g2d.setColor(Color.GRAY);
        g2d.drawString("world (0,0) — Y points up", (int) origin.x + 4, (int) origin.y - 4);
    }

    /** Reset the canvas back to an empty state. */
    public void clear() {
        vertices.clear();
        closed = false;
        statusLabel.setText("Cleared. Click to start a new polygon.");
        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Geo-snapping: digitise a polygon");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel status = new JLabel("Click to add a vertex. Snap to first point to close.");
        GeoSnapExample canvas = new GeoSnapExample(status);

        JButton clear = new JButton("Clear");
        clear.addActionListener(e -> canvas.clear());

        JPanel controls = new JPanel();
        controls.add(status);
        controls.add(clear);

        frame.setLayout(new BorderLayout());
        frame.add(canvas, BorderLayout.CENTER);
        frame.add(controls, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }
}
