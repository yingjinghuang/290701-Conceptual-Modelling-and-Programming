package at.ac.univie.gis.week7.basicui;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * A tiny greeting form built from the five most common Swing components:
 *
 *   - JFrame      the outer window
 *   - JPanel      the invisible canvas that holds the other components
 *   - JLabel      static, non-editable text
 *   - JTextField  single-line user input
 *   - JButton     a clickable element
 *
 * The panel uses GridLayout(3, 1) so the three components stack vertically and
 * stretch to fill the window. Try commenting out the setLayout(...) line to see
 * the messy default FlowLayout for comparison.
 *
 * The button is wired up with a lambda ActionListener: one line, no anonymous
 * inner class boilerplate.
 *
 * Things to play with after class:
 *   - Replace GridLayout with new FlowLayout() or new BorderLayout()
 *   - Resize the window and observe how the layout reacts
 *   - Add a second button that clears the text field
 */
public class BasicUIExample {

    public static void main(String[] args) {
        // Step 1: create the outer window and tell it to actually quit
        // the program when the user closes it.
        JFrame frame = new JFrame("Greeting Form");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Step 2: add an invisible panel inside the window. All visible
        // components live on the panel, not directly on the frame.
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1)); // three rows, one column
        frame.add(panel);

        // Step 3: create the three interactive components. Nothing is
        // visible yet — we only constructed the objects.
        JLabel label = new JLabel("Enter your name:");
        JTextField textField = new JTextField(15);
        JButton button = new JButton("Greet me!");

        // Step 4: add them to the panel in the order we want them to appear.
        panel.add(label);
        panel.add(textField);
        panel.add(button);

        // Step 5: wire the button with a lambda ActionListener.
        // The lambda runs every time the user clicks the button.
        // The verbose form would be:
        //     button.addActionListener(new ActionListener() { ... });
        button.addActionListener(e -> {
            String name = textField.getText();
            if (name == null || name.isBlank()) {
                label.setText("Please type your name first.");
            } else {
                label.setText("Hello, " + name + "!");
            }
        });

        // Step 6: finally, make the window visible. Until this call,
        // everything we built lives only in memory.
        frame.setVisible(true);
    }
}
