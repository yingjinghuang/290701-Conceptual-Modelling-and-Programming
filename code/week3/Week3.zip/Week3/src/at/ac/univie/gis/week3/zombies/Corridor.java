package at.ac.univie.gis.week3.zombies;

import java.util.Arrays;

/**
 * A single linear corridor of cells. Each cell holds a zombie count.
 *
 * Movement rule (slide 33): if a cell holds more than one zombie,
 * one moves to the cell on its left and one disappears. The leftmost
 * cell cannot move further left, so its outgoing zombie just vanishes.
 *
 * The rule is applied to every cell based on its state at the *start*
 * of the step. We achieve that by writing into a copy.
 */
public class Corridor {

    private int[] cells;

    public Corridor(int[] initial) {
        this.cells = initial.clone();
    }

    /**
     * The simulation has stabilised when no cell has more than one zombie.
     */
    public boolean isStable() {
        for (int c : cells) {
            if (c > 1) return false;
        }
        return true;
    }

    public void step() {
        int[] next = cells.clone();
        for (int i = 0; i < cells.length; i++) {
            if (cells[i] > 1) {
                next[i] -= 2;
                if (i > 0) {
                    next[i - 1] += 1;
                }
            }
        }
        cells = next;
    }

    @Override
    public String toString() {
        return Arrays.toString(cells);
    }
}
