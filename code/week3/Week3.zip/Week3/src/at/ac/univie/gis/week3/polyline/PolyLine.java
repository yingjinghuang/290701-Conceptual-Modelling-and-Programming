package at.ac.univie.gis.week3.polyline;

import java.util.ArrayList;

/**
 * PolyLine HAS-A list of points (delegation), it is NOT-A list.
 * We do not write "class PolyLine extends ArrayList" — a polyline is
 * not a kind of list, it just uses one internally to store its vertices.
 *
 * Outside callers only see the methods we choose to expose
 * (addPoint, size, get, length). The ArrayList itself stays private.
 */
public class PolyLine {

    private ArrayList<Point> vertices;

    public PolyLine() {
        vertices = new ArrayList<Point>();
    }

    public void addPoint(Point p) {
        vertices.add(p);
    }

    public int size() {
        return vertices.size();
    }

    public Point get(int index) {
        return vertices.get(index);
    }

    /**
     * Total length: sum of distances between consecutive vertices.
     * A two-vertex polyline reduces to one segment; a one-vertex or
     * empty polyline has length 0.
     */
    public double length() {
        double total = 0;
        for (int i = 1; i < vertices.size(); i++) {
            total += vertices.get(i - 1).distanceTo(vertices.get(i));
        }
        return total;
    }
}
