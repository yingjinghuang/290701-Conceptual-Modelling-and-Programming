package at.ac.univie.gis.week3.inheritance;

/**
 * Demonstrates the three ideas from the inheritance block:
 *   1. extends + super(...) constructor handoff
 *   2. toString override (dispatched at runtime)
 *   3. equals override vs ==
 */
public class InheritanceMain {

    public static void main(String[] args) {

        // A Point IS-A Geometry, so a Geometry-typed variable can hold a Point.
        // When we print g, Java picks Point's toString at runtime, not Geometry's.
        Geometry g = new Point("origin", 0, 0);
        System.out.println(g);

        // Two distinct Point objects with the same coordinates.
        Point a = new Point("a", 3, 4);
        Point b = new Point("b", 3, 4);
        Point c = a;

        // == compares object identity (memory address).
        // .equals compares values, because we overrode it on Point.
        System.out.println("a == b:       " + (a == b));        // false: different objects
        System.out.println("a.equals(b):  " + a.equals(b));     // true: same coordinates
        System.out.println("a == c:       " + (a == c));        // true: same reference
    }
}
