package at.ac.univie.gis.week3.polyline;

/**
 * A simple 2D point used by PolyLine. Kept independent from the
 * inheritance package so the delegation example stays self-contained.
 * (Two classes named Point can coexist because they live in different
 * packages — that's exactly what packages buy you.)
 */
public class Point {

    private double x;
    private double y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double distanceTo(Point other) {
        double dx = x - other.x;
        double dy = y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}
