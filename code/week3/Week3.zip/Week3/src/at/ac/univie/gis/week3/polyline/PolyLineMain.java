package at.ac.univie.gis.week3.polyline;

/**
 * Builds a small polyline, iterates over its vertices, prints each one,
 * and finally prints the total length. Demonstrates how an ArrayList
 * makes "I do not know yet how many points there will be" a non-issue.
 */
public class PolyLineMain {

    public static void main(String[] args) {
        PolyLine line = new PolyLine();
        line.addPoint(new Point(0, 0));
        line.addPoint(new Point(3, 0));
        line.addPoint(new Point(3, 4));

        for (int i = 0; i < line.size(); i++) {
            System.out.println("vertex " + i + ": " + line.get(i));
        }

        System.out.println("total length: " + line.length());
    }
}
