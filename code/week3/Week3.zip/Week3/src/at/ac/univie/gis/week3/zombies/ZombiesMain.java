package at.ac.univie.gis.week3.zombies;

/**
 * Runs the zombie corridor simulation from the slide:
 * start with [0, 0, 0, 0, 4], step until every cell holds at most one.
 */
public class ZombiesMain {

    public static void main(String[] args) {
        Corridor corridor = new Corridor(new int[]{0, 0, 0, 0, 4});

        int step = 0;
        System.out.println("step " + step + ": " + corridor);

        while (!corridor.isStable()) {
            corridor.step();
            step++;
            System.out.println("step " + step + ": " + corridor);
        }

        System.out.println("stable after " + step + " steps");
    }
}
