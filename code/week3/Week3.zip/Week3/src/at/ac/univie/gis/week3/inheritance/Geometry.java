package at.ac.univie.gis.week3.inheritance;

/**
 * A simple parent class in our small geometry hierarchy.
 * Every Geometry has a name (just a label, e.g. "origin", "lake-outline").
 *
 * The name field is protected, which is the visibility level introduced
 * on slide 23: visible to this class and to any subclass, but not to
 * unrelated outside code.
 */
public class Geometry {

    // protected: a subclass like Point can read and write this field directly.
    protected String name = "";

    public String getName() {
        return name;
    }

    /**
     * Default text representation. Subclasses typically override this
     * to include their own fields (see Point.toString).
     */
    @Override
    public String toString() {
        return "Geometry{name=" + name + "}";
    }
}
