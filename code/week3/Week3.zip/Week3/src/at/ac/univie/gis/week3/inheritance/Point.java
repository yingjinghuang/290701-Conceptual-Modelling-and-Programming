package at.ac.univie.gis.week3.inheritance;

/**
 * A Point is-a Geometry, with two coordinate fields added on top.
 * Demonstrates extends, accessing a protected field from a subclass,
 * and overriding both toString and equals.
 */
public class Point extends Geometry {

    private double x;
    private double y;

    public Point(String name, double x, double y) {
        // Parent construction always happens first — Java runs Geometry's
        // no-arg constructor before any line in this body executes.
        // We then assign the inherited 'name' field directly, which is
        // possible because Geometry declared it protected (slide 23).
        this.name = name;
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    /**
     * Override Geometry's toString so println shows the coordinates,
     * not just "Geometry{name=...}".
     */
    @Override
    public String toString() {
        return "Point{name=" + name + ", x=" + x + ", y=" + y + "}";
    }

    /**
     * Override Object's equals so two Points with the same coordinates
     * compare equal. Without this, .equals falls back to == (identity).
     * getClass() comes from Object — every class has it for free.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || o.getClass() != this.getClass()) return false;
        Point other = (Point) o;
        return x == other.x && y == other.y;
    }
}
