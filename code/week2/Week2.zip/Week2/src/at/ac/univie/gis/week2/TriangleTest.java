package at.ac.univie.gis.week2;

// The Triangle class is your model/blueprint of a triangle and has no main method.
// This class here is for testing your model, i.e., for creating specific triangle objects.

public class TriangleTest {

    public static void main(String[] args) {

        // Create three triangles with different side lengths.
        Triangle t1 = new Triangle(3, 4, 5);           // A classic right triangle.
        Triangle t2 = new Triangle(6, 6, 6);           // An equilateral triangle.
        Triangle t3 = new Triangle(5.5, 7.2, 9.1);     // An arbitrary triangle.

        // Put them into an array so we can iterate over them.
        Triangle[] triangles = {t1, t2, t3};

        // Iterate over all triangles and print their side lengths, perimeter, and area.
        for (int i = 0; i < triangles.length; i++) {
            Triangle t = triangles[i];
            System.out.println("Triangle " + (i + 1)
                    + " (a=" + t.getSideA()
                    + ", b=" + t.getSideB()
                    + ", c=" + t.getSideC() + ")"
                    + " -> perimeter = " + t.calculatePerimeter()
                    + ", area = " + t.calculateArea());
        }

        // Demonstrate setters: change one side and recompute.
        t1.setSideA(6);
        t1.setSideB(8);
        t1.setSideC(10);
        System.out.println("After resizing t1: perimeter = " + t1.calculatePerimeter()
                + ", area = " + t1.calculateArea());

        // Demonstrate input validation: try to create an invalid triangle.
        try {
            Triangle invalid = new Triangle(1, 1, 5); // violates the triangle inequality
            System.out.println("This line should not be reached: " + invalid.calculateArea());
        } catch (IllegalArgumentException e) {
            System.out.println("Caught expected error: " + e.getMessage());
        }
    }
}
