package at.ac.univie.gis.week2;

public class Farm {

	// Member variables are private - only accessible through getters/setters (encapsulation).
	private String name = "";       // An empty string that will store the name of the farm
	private int nrOfEmployees = 0;  // The number of employees is set to 0 as default value.

	// This constructor does not take the number of employees as additional input and, hence, it will remain 0.
	public Farm(String name){
		// The local 'name' variable will be stored in the member variable above.
		this.name = name;
	}

	// This constructor also allows to specify a number of employees.
	public Farm(String name, int nrOfEmployees){
		this.name = name;
		this.nrOfEmployees = nrOfEmployees;
	}

	// This returns the value stored in the member variable name.
	public String getName(){
		return name;
	}

	// Assigns a new value to name, e.g., to change the name of the farm.
	public void setName(String newName){
		this.name = newName;
	}

	// This just returns the number of employees of the farm.
	public int getNrOfEmployees() {
		return nrOfEmployees;
	}

	// This method allows you to change the number of employees.
	public void setNrOfEmployees(int nrOfEmployees) {
		this.nrOfEmployees = nrOfEmployees;
	}
}
