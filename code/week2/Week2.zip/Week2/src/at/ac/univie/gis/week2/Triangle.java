package at.ac.univie.gis.week2;

/**
 * A simple Triangle class demonstrating encapsulation, constructors, and methods.
 * The three sides define the triangle, and we can compute perimeter and area from them.
 */
public class Triangle {

    // Private member variables - only accessible through getters/setters (encapsulation)
    private double sideA;
    private double sideB;
    private double sideC;

    /**
     * Constructor: creates a triangle with three given side lengths.
     * The keyword 'this' distinguishes member variables from constructor parameters.
     */
    public Triangle(double sideA, double sideB, double sideC) {
        if (sideA <= 0 || sideB <= 0 || sideC <= 0) {
            throw new IllegalArgumentException("Side lengths must be positive.");
        }
        // Triangle inequality: the sum of any two sides must be greater than the third.
        if (sideA + sideB <= sideC || sideA + sideC <= sideB || sideB + sideC <= sideA) {
            throw new IllegalArgumentException("The given sides do not form a valid triangle.");
        }
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
    }

    // --- Getters: return the current values of private fields ---

    public double getSideA() {
        return sideA;
    }

    public double getSideB() {
        return sideB;
    }

    public double getSideC() {
        return sideC;
    }

    // --- Setters: allow controlled modification of private fields ---

    public void setSideA(double sideA) {
        this.sideA = sideA;
    }

    public void setSideB(double sideB) {
        this.sideB = sideB;
    }

    public void setSideC(double sideC) {
        this.sideC = sideC;
    }

    /**
     * Calculates the perimeter (sum of all three sides).
     */
    public double calculatePerimeter() {
        return sideA + sideB + sideC;
    }

    /**
     * Calculates the area using Heron's formula.
     * Given semi-perimeter s = perimeter / 2, the area = sqrt(s * (s-a) * (s-b) * (s-c)).
     * Note how this method reuses calculatePerimeter() - methods can call other methods.
     */
    public double calculateArea() {
        double s = calculatePerimeter() / 2;
        return Math.sqrt(s * (s - sideA) * (s - sideB) * (s - sideC));
    }
}
