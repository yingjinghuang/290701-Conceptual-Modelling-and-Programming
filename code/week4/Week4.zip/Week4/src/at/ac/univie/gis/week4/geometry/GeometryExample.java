package at.ac.univie.gis.week4.geometry;

import java.util.ArrayList;

/**
 * Driver for the abstract-class example.
 *
 * Notice:
 *   - We can declare ArrayList<Geometry> even though Geometry is abstract.
 *   - We CANNOT do `new Geometry(...)` — the compiler rejects it.
 *   - Each shape's own getArea() runs at the right moment via dynamic dispatch.
 */
public class GeometryExample {

    public static void main(String[] args) {

        ArrayList<Geometry> shapes = new ArrayList<>();
        shapes.add(new Circle("c1", 3.0));
        shapes.add(new Rectangle("r1", 4.0, 5.0));
        shapes.add(new Circle("c2", 1.5));

        // Polymorphism: same call, different formulas chosen per object.
        for (Geometry g : shapes) {
            System.out.println(g.describe());
        }

        // Uncomment to see the compile error abstract classes give you:
        // Geometry g = new Geometry("nope");
    }
}
