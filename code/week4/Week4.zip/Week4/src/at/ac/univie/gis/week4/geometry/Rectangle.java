package at.ac.univie.gis.week4.geometry;

/**
 * Another concrete subclass of Geometry, with its own area formula.
 */
public class Rectangle extends Geometry {

    private double width;
    private double height;

    public Rectangle(String label, double width, double height) {
        super(label);
        this.width = width;
        this.height = height;
    }

    @Override
    public double getArea() {
        return width * height;
    }
}
