package at.ac.univie.gis.week4.geometry;

/**
 * A concrete subclass of the abstract Geometry class.
 * Must provide its own getArea() — the compiler enforces this.
 */
public class Circle extends Geometry {

    private double radius;

    public Circle(String label, double radius) {
        super(label);
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }
}
