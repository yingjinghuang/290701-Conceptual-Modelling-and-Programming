package at.ac.univie.gis.week4.watercourse;

/**
 * A River is a specific kind of Watercourse that also has a Spring (origin).
 *
 * Demonstrates two inheritance ideas at once:
 *   - super(length) in the constructor hands data up to the parent.
 *   - describe() is OVERRIDDEN below, and uses super.describe() to add to —
 *     not replace — the parent's behaviour.
 */
public class River extends Watercourse {

    private Spring origin;

    public River(int length, Spring origin) {
        super(length);
        this.origin = origin;
    }

    public Spring getOrigin() {
        return origin;
    }

    public void setOrigin(Spring origin) {
        this.origin = origin;
    }

    /**
     * Override describe() to include the spring name on top of what
     * Watercourse already returns.
     */
    @Override
    public String describe() {
        return super.describe() + ", originating at spring " + origin.getName();
    }
}
