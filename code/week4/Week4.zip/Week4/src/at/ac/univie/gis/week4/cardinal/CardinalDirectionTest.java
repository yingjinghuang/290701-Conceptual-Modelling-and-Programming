package at.ac.univie.gis.week4.cardinal;

/**
 * Simple test to demonstrate how enums are used.
 * Enum values can be printed, compared, and passed to methods just like other objects.
 */
public class CardinalDirectionTest {

    public static void main(String[] args) {
        // Access an enum value using ClassName.VALUE
        System.out.println(CardinalDirection.WEST);
    }
}
