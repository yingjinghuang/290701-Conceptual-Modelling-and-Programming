package at.ac.univie.gis.week4.sir;

/**
 * A 2D point used to represent a person's location in the SIR simulation.
 *
 * Mostly stable — you probably won't need to change this file for the Week 4
 * assignment, but you can add small helpers here if you find yourself wanting
 * them (e.g. a constructor that places a point at a random location given an
 * existing random source).
 */
public class Point {

    private double x, y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Returns a human-readable string representation of the point.
     * Overriding toString() allows meaningful output in System.out.println().
     */
    @Override
    public String toString() {
        return "Point{x=" + x + ", y=" + y + '}';
    }

    /**
     * Computes the Euclidean distance to another point.
     */
    public double distanceTo(Point other) {
        return Math.sqrt(Math.pow(x - other.getX(), 2) + Math.pow(y - other.getY(), 2));
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
}
