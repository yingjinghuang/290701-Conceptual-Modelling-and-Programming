package at.ac.univie.gis.week4.sir;

/**
 * Represents a person in the SIR (Susceptible-Infectious-Removed) model.
 * Each person has a location and a health state.
 *
 * --- Week 4 assignment notes ---
 *
 *   - move() currently uses Math.random(). Mandatory task 1 (reproducible
 *     placement) means every random draw in your simulation should come from
 *     a controlled, seeded source. Whether this class keeps owning the random
 *     draw, or hands that responsibility off to whoever calls it, is a design
 *     decision you'll have to make.
 *
 *   - changeState() currently flips state deterministically. Mandatory task 2
 *     (stochastic infection) means SUSCEPTIBLE -> INFECTIOUS should only
 *     happen when a probability roll succeeds; the deterministic flip needs
 *     to evolve.
 *
 *   - The state constants below could move to Disease as part of task 3, but
 *     that is itself a design choice — they could equally well stay here.
 *
 * Note: The states are modeled as integer constants here. Using an enum would
 * be cleaner (type-safe, no invalid values possible) — see the
 * CardinalDirection example in the cardinal/ package.
 */
public class Person {

    // State constants - using static final makes them shared across all Person instances
    public static final int SUSCEPTIBLE = 1;
    public static final int INFECTIOUS = 2;
    public static final int REMOVED = 3;

    private Point location;
    private int state = SUSCEPTIBLE;

    /**
     * Creates a person at a given location with an initial health state.
     */
    public Person(Point location, int state) {
        this.location = location;
        this.state = state;
    }

    /**
     * Advances the person's state: SUSCEPTIBLE -> INFECTIOUS -> REMOVED.
     * Once REMOVED, the state does not change further.
     */
    public int changeState() {
        if (state == SUSCEPTIBLE) {
            state = INFECTIOUS;
        } else if (state == INFECTIOUS) {
            state = REMOVED;
        }
        return state;
    }

    /**
     * Moves the person to a random location within a 100x100 area.
     */
    public void move() {
        location.setX(Math.random() * 100);
        location.setY(Math.random() * 100);
    }

    public Point getLocation() {
        return location;
    }

    public void setLocation(Point location) {
        this.location = location;
    }

    public int getState() {
        return state;
    }

    /**
     * Returns the state as a human-readable string instead of an integer.
     */
    public String getStateName() {
        switch (state) {
            case SUSCEPTIBLE:
                return "SUSCEPTIBLE";
            case INFECTIOUS:
                return "INFECTIOUS";
            case REMOVED:
                return "REMOVED";
            default:
                return "UNKNOWN";
        }
    }

    @Override
    public String toString() {
        return "Person{location=" + location + ", state=" + getStateName() + '}';
    }
}
