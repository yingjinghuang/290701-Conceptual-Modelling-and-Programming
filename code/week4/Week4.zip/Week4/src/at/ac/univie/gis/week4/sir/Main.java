package at.ac.univie.gis.week4.sir;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * SIR (Susceptible-Infectious-Removed) simulation entry point.
 * This is the Week 3 starting code. Most of your Week 4 work lands in this file.
 *
 * --- Week 4 assignment behaviour goals ---
 *
 *   1. Reproducible random placement.
 *      Every Person should land at a random location inside the rectangular
 *      study area. Two back-to-back runs of your simulation should produce
 *      the SAME starting layout, so you can debug a strange run.
 *
 *   2. Stochastic infection.
 *      When an infectious person is within the infection radius of a
 *      susceptible person, the susceptible should become infectious WITH the
 *      given probability — sometimes yes, sometimes no, in proportion to that
 *      probability. This is the upgrade from W3, where "risk" was just a
 *      number; here a state actually changes (or doesn't).
 *
 *   3. Disease class for parameters.
 *      The infection probability and the infection radius should live in the
 *      Disease class (see Disease.java), not as magic numbers in this file.
 *
 *   How you organise the implementation — where the Random object lives,
 *   whether you keep using Main or pull a separate Simulation class out, how
 *   Disease is wired in — is your design call.
 *
 * --- Reference packages in this week's code ---
 *
 *   - cardinal/RandomLocations.java — Random's four methods + seeding
 *   - watercourse/                  — extends, super, override, instanceof
 *   - geometry/                     — abstract class with concrete subclasses
 */
public class Main {

    ArrayList<Person> population;

    /**
     * Sets up the initial population: one infectious person and several susceptible ones.
     */
    public Main() {
        population = new ArrayList<Person>();
        population.add(new Person(new Point(10, 10), Person.INFECTIOUS));
        population.add(new Person(new Point(11, 12), Person.SUSCEPTIBLE));
        population.add(new Person(new Point(12, 13), Person.SUSCEPTIBLE));
        population.add(new Person(new Point(21, 19), Person.SUSCEPTIBLE));
        population.add(new Person(new Point(15, 11), Person.SUSCEPTIBLE));
        population.add(new Person(new Point(17, 16), Person.SUSCEPTIBLE));
        population.add(new Person(new Point(23, 22), Person.SUSCEPTIBLE));
    }

    public static void main(String[] args) {
        Main SIRrun = new Main();
        // In a full simulation, this would run in a loop (multiple time steps)
        SIRrun.SIRstep();
    }

    /**
     * A single SIR step: the first person (infectious) infects anyone within distance 5.
     * This is a simplified version - only the first person is checked as a source.
     */
    public void SIRstep() {
        Iterator<Person> SIRcheck = population.iterator();

        // Get the first person (the infectious one)
        Person temp = null;
        if (SIRcheck.hasNext())
            temp = SIRcheck.next();

        // Compare the first person against all remaining persons
        while (SIRcheck.hasNext()) {
            Person toCheck = SIRcheck.next();
            System.out.println("\nBefore: " + toCheck);

            // If within distance 5 of the infectious person, change state
            if (temp.getLocation().distanceTo(toCheck.getLocation()) < 5)
                toCheck.changeState();

            System.out.println("After: " + toCheck);
        }
    }

    /**
     * TODO: Compare ALL pairs of persons, not just the first one against the rest.
     * This would be a nested loop: for each infectious person, check all susceptible ones.
     */
    public void SIRstepAll() {
        // TBD - Exercise for students
    }
}
