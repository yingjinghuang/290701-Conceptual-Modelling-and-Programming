package at.ac.univie.gis.week4.sir;

/**
 * Holds the parameters of the disease used by this simulation.
 *
 * --- Week 4 assignment context ---
 *
 * Mandatory task 3:
 *   Infection probability and infection radius should live in ONE designated
 *   place — not as magic numbers scattered through Main and Person. Every part
 *   of your simulation that needs them should refer to them through this class.
 *
 *   How exactly you expose them on Disease (e.g. constants, instance fields,
 *   getters) is a design decision left to you. Be aware that the stretch goal
 *   will put that choice under some pressure, so it's worth thinking ahead
 *   about whether your design extends naturally to "more than one kind of
 *   disease."
 *
 * Stretch goal:
 *   Support multiple kinds of disease (e.g. airborne vs contact-based) whose
 *   transmission probabilities differ. The simulation should be runnable with
 *   any one of them, and the generic Disease itself should not be directly
 *   instantiable. If you take this on, you'll create one or more concrete
 *   subclass files yourself.
 *
 *   The geometry/ reference package in this week's code shows the abstract +
 *   concrete-subclasses pattern end to end.
 */
public class Disease {

    // Your design goes here.
}
