package at.ac.univie.gis.week4.geometry;

/**
 * An ABSTRACT base class for geometric shapes.
 *
 * 'abstract' on the class means: you cannot do `new Geometry(...)`.
 * Geometry is not a real shape — every real shape is a Circle or Rectangle
 * or some other concrete subclass.
 *
 * 'abstract' on getArea() means: every subclass MUST provide its own
 * implementation. The compiler will refuse to compile a subclass that
 * forgets to implement getArea().
 */
public abstract class Geometry {

    private String label;

    public Geometry(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    /**
     * Abstract method — no body, just a contract.
     * Each subclass fills this in with its own area formula.
     */
    public abstract double getArea();

    /**
     * A concrete method on an abstract class is allowed.
     * It can call the abstract method — the call resolves to the
     * subclass implementation at runtime (dynamic dispatch).
     */
    public String describe() {
        return label + " has area " + getArea();
    }
}
