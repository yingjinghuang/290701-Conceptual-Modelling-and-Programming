package at.ac.univie.gis.week4.watercourse;

/**
 * Represents the source (spring) of a river.
 * A simple class with just a name, used in composition with River.
 */
public class Spring {

    private String name;

    public Spring(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
