package at.ac.univie.gis.week4.watercourse;

import java.util.ArrayList;

/**
 * Demonstrates inheritance, polymorphism, dynamic dispatch, and instanceof.
 *
 * An ArrayList<Watercourse> can hold both Watercourse and River objects
 * because River IS-A Watercourse.
 *
 * When we call describe() on each element, Java looks at the REAL object type
 * at runtime — Rivers run River.describe(), plain Watercourses run
 * Watercourse.describe(). That is dynamic dispatch.
 */
public class WatercourseExample {

    public static void main(String[] args) {

        ArrayList<Watercourse> watercourses = new ArrayList<>();

        watercourses.add(new Watercourse(1246));
        watercourses.add(new Watercourse(541));
        watercourses.add(new Watercourse(1496));
        watercourses.add(new Watercourse(996));
        // A River fits in the same list because it extends Watercourse.
        watercourses.add(new River(766, new Spring("Rheinquelle")));

        for (Watercourse w : watercourses) {
            // Dynamic dispatch: each object decides which describe() runs.
            System.out.println(w.describe());

            // Only Rivers carry a Spring. Use instanceof to ask the question
            // safely before reaching for River-only data.
            if (w instanceof River r) {
                System.out.println("  spring object: " + r.getOrigin().getName());
            }
        }
    }
}
