package at.ac.univie.gis.week4.cardinal;

/**
 * An enum representing the four cardinal directions.
 * Enums provide type-safe constants - you cannot accidentally use an invalid direction.
 * Compare this to using plain integers (1=North, 2=South...) which are error-prone.
 */
public enum CardinalDirection {
    NORTH, SOUTH, EAST, WEST
}
