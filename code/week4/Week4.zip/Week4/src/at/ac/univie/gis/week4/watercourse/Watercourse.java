package at.ac.univie.gis.week4.watercourse;

/**
 * A simple base class representing a watercourse (any body of flowing water).
 * Serves as the parent class in an inheritance hierarchy.
 */
public class Watercourse {

    private double length;

    public Watercourse(int length) {
        this.length = length;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    /**
     * Returns a short description of this watercourse.
     * Subclasses can OVERRIDE this method to add their own information,
     * and call super.describe() to keep the parent's contribution.
     */
    public String describe() {
        return "Watercourse of length " + length;
    }
}
