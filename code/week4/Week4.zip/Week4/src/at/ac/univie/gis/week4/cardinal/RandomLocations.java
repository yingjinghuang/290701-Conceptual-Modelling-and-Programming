package at.ac.univie.gis.week4.cardinal;

import java.util.Random;

/**
 * Demonstrates java.util.Random for use in spatial simulations.
 *
 * Two things to take away:
 *   (1) Random gives you four flavours of randomness: nextInt, nextDouble,
 *       nextBoolean, nextGaussian. Math.random() only gives you one.
 *   (2) Passing a seed to the constructor makes the sequence reproducible —
 *       the same seed always produces the same numbers. Useful while debugging.
 */
public class RandomLocations {

    public static void main(String[] args) {

        // --- (1) The four methods on Random --------------------------------

        // No seed → time-based, different every run.
        Random rng = new Random();

        // Random integer in [0, 501)  → e.g. an x-coordinate on a 500-wide grid.
        int x = rng.nextInt(501);

        // Random double in [0.0, 1.0) → multiply by area width to place a person.
        double y = rng.nextDouble() * 500;

        // Random true/false with equal probability.
        boolean coin = rng.nextBoolean();

        // Sample from the standard normal distribution N(0, 1) — handy for noise.
        double noise = rng.nextGaussian();

        System.out.println("x: " + x);
        System.out.println("y: " + y);
        System.out.println("coin: " + coin);
        System.out.println("noise: " + noise);

        // Math.random() is essentially shorthand for new Random().nextDouble().
        // Fine for one-off rolls, but you cannot seed it.
        System.out.println("Math.random(): " + Math.random());

        // --- (2) Seeded Random for reproducible runs -----------------------

        // Two generators built from the SAME seed produce the SAME sequence.
        // Run this main method twice and these four numbers stay identical.
        Random seeded = new Random(42);
        System.out.println("\nSeeded run (always the same):");
        for (int i = 0; i < 4; i++) {
            System.out.println("  " + seeded.nextDouble());
        }
    }
}
