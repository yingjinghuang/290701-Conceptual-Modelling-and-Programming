package at.ac.univie.gis.week1;

/**
 * Week 1 - Introduction to Java basics: output, arithmetic, variables, loops, and methods.
 */
public class Week1 {

    public static void main(String[] args) {

        // --- Section 1: Output and basic arithmetic ---
        System.out.println("Discrete Mathematics");

        // Parentheses force arithmetic addition: 1+1 = 2
        System.out.println("1+1: " + (1 + 1));

        // Without parentheses, + performs string concatenation: "Same here: " + "1" + "1" = "Same here: 11"
        System.out.println("Same here: " + 1 + 1);

        // Integer division: 10/10 = 1 (no decimal places)
        System.out.println("1000/1000 yields: " + (10 / 10));

        // WARNING: Integer division by zero throws ArithmeticException and crashes the program!
        // Uncomment the next line to see it in action (the program will stop here):
        // System.out.println("42/0 yields: " + (42 / 0));

        // Floating-point division by zero does NOT crash - it returns Infinity instead.
        // This is because IEEE 754 floating-point standard defines division by zero as Infinity.
        System.out.println("42.0/0 yields: " + (42.0 / 0));

        // Floating-point precision: 0.1 + 0.1 = 0.2 (exact)
        System.out.println("0.1+0.1 yields: " + (0.1 + 0.1));

        // But 0.1 + 0.1 + 0.1 is NOT exactly 0.3 due to floating-point representation!
        System.out.println("0.1+0.1+0.1 yields: " + (0.1 + 0.1 + 0.1));

        // --- Section 2: Variables ---
        double distance1;       // Declare a variable (no initial value yet)
        distance1 = 10;         // Assign a value later
        double distance2 = 5;   // Declare and initialize in one step

        // Math.max returns the larger of two values
        System.out.println("Max: " + Math.max(distance1, distance2));

        // Calling a custom method (defined below)
        System.out.println("add-one: " + addOne(distance2));

        // --- Section 3: Loops and Math functions ---
        // Print the square of each number from 0 to 9 using Math.pow()
        for (int i = 0; i < 10; i++) {
            System.out.println(Math.pow(i, 2));
        }

        // --- Section 4: Conditionals (uncomment to try) ---
        // int count = 4;
        // if (count == 42) {
        //     System.out.println("THE answer!");
        // } else {
        //     System.out.println("hmmm...");
        // }
    }

    /**
     * A simple method that adds 1 to the input value.
     * Demonstrates how to define and call a static method.
     */
    public static double addOne(double in) {
        return in + 1;
    }
}
