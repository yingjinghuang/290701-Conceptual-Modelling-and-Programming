package at.ac.univie.gis.week8.sir;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.function.DoubleConsumer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.Timer;

/**
 * CONTROLLER — wires the buttons, sliders and timer to the model and views, and
 * owns main(). The Timer fires repeatedly to advance the simulation.
 *
 * There are TWO views of the one model: the grid (SirView) and the live line
 * chart (SirChart). The controller records the counts into the chart after every
 * step — all provided.
 *
 * YOUR JOB here is TODO (4): design the GUI LAYOUT — decide how the controls, the
 * map (view), the chart and the status line are arranged in the window.
 */
public class SirController {

    private final SirModel model;
    private final SirView view;
    private final SirChart chart = new SirChart();
    private final Timer timer;
    private final JLabel status = new JLabel(" ");

    private int day = 0;            // how many days (steps) have passed
    private int peakInfectious = 0; // highest Infectious count seen this run

    public SirController(SirModel model, SirView view) {
        this.model = model;
        this.view = view;
        this.timer = new Timer(100, e -> advanceOneDay());
    }

    /** One simulated day: step the model, then refresh both views and the counts. */
    private void advanceOneDay() {
        model.step();
        day++;
        view.repaint();
        recordSample();
        updateStatus();
    }

    /** Add the current S/I/R counts as the next point on the chart. */
    private void recordSample() {
        chart.addSample(model.count(SirModel.S),
                        model.count(SirModel.I),
                        model.count(SirModel.R));
        chart.repaint();
    }

    /** Build all the controls, lay them out, and show the window. */
    public void start() {
        // --- sliders (provided, already wired to the model) ---
        JPanel infection = labelledSlider("Infection", 0.30, model::setInfectionRate);
        JPanel recovery  = labelledSlider("Recovery",  0.08, model::setRecoveryRate);
        JPanel stayHome  = labelledSlider("Stay-home", 0.00, model::setStayHome);
        JPanel density   = labelledSlider("Density",   0.30, model::setDensity);

        // --- buttons (provided, already wired) ---
        JButton startBtn = new JButton("Start");
        startBtn.addActionListener(e -> timer.start());

        JButton pauseBtn = new JButton("Pause");
        pauseBtn.addActionListener(e -> timer.stop());

        JButton stepBtn = new JButton("Step");
        stepBtn.addActionListener(e -> advanceOneDay());

        JButton resetBtn = new JButton("Reset");
        resetBtn.addActionListener(e -> {
            timer.stop();
            model.reset();
            day = 0;
            peakInfectious = 0;
            chart.clear();
            view.repaint();
            recordSample();
            updateStatus();
        });

        JFrame frame = new JFrame("SIR Epidemic Simulation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // ===================================================================
        //  TODO (4) — DESIGN YOUR OWN GUI.
        //
        //  Below is a BARE-BONES starter layout so the program runs right away:
        //  just the four buttons, the grid, and the status line. Use it to test
        //  your model code (press Step / Start once you have written step()).
        //
        //  Then make the interface your own by extending this:
        //     * add the four sliders:  infection, recovery, stayHome, density
        //     * add the live chart:    chart   (put it next to the grid)
        //     * arrange everything with a layout of your choice
        //
        //  Tip: a plain new JPanel() uses FlowLayout, which places the grid and
        //  the chart side by side at their natural sizes without stretching, so
        //  there is no empty gap between them. (A JFrame's content area already
        //  uses BorderLayout, which is why frame.add(..., NORTH/CENTER/SOUTH)
        //  works below.)
        // ===================================================================
        JPanel buttons = new JPanel();
        buttons.add(startBtn);
        buttons.add(pauseBtn);
        buttons.add(stepBtn);
        buttons.add(resetBtn);

        frame.add(buttons, BorderLayout.NORTH);
        frame.add(view, BorderLayout.CENTER);
        frame.add(status, BorderLayout.SOUTH);
        // (the sliders and the chart are created above but not placed yet —
        //  adding them is your job)

        frame.pack();
        frame.setVisible(true);

        recordSample(); // plot day 0
        updateStatus();
    }

    /** Show the day, the current S / I / R counts, and the peak so far. */
    private void updateStatus() {
        int i = model.count(SirModel.I);
        if (i > peakInfectious) peakInfectious = i;
        status.setText("  Day: " + day
                + "      Susceptible: " + model.count(SirModel.S)
                + "      Infectious: " + i
                + "      Recovered: " + model.count(SirModel.R)
                + "      Peak infectious: " + peakInfectious);
    }

    /**
     * Build a label + slider that reports its value (as a fraction 0..1) to the
     * given setter whenever it is moved. (Provided.)
     */
    private JPanel labelledSlider(String name, double initial, DoubleConsumer onChange) {
        JSlider slider = new JSlider(0, 100, (int) Math.round(initial * 100));
        slider.setPreferredSize(new Dimension(120, slider.getPreferredSize().height));
        JLabel label = new JLabel(name + ": " + slider.getValue() + "%");
        slider.addChangeListener(e -> {
            int v = slider.getValue();
            label.setText(name + ": " + v + "%");
            onChange.accept(v / 100.0);
        });
        JPanel panel = new JPanel();
        panel.add(label);
        panel.add(slider);
        return panel;
    }

    public static void main(String[] args) {
        SirModel model = new SirModel(80);          // an 80 x 80 grid
        SirView view = new SirView(model);
        new SirController(model, view).start();
    }
}
