package at.ac.univie.gis.week8.mvc.after;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * MODEL (the "M" in MVC) — Slide 6.
 *
 * The Model holds the data and the logic that operates on it, and NOTHING else.
 * In this tiny example the "data" is just the list of clicked points.
 *
 * THE IRON RULE: a Model must not import anything from java.awt.* or
 * javax.swing.*. Notice there is not a single GUI import below. That is also why
 * we store each point as a plain int[]{x, y} rather than the convenient
 * java.awt.Point — using java.awt.Point would drag the GUI toolkit into the
 * Model and break the separation.
 *
 * The payoff: because this class knows nothing about windows, you could reuse it
 * in a command-line program or test it automatically, with no screen at all.
 */
public class PointsModel {

    // The single piece of state this model owns.
    private final List<int[]> points = new ArrayList<>();

    /** Add a point at pixel position (x, y). */
    public void add(int x, int y) {
        points.add(new int[]{x, y});
    }

    /** Remove every point. */
    public void clear() {
        points.clear();
    }

    /** How many points we currently hold (handy for the View's status text). */
    public int size() {
        return points.size();
    }

    /**
     * Hand the View a READ-ONLY view of the points to draw.
     *
     * Collections.unmodifiableList wraps the list so that if the View ever tried
     * to add or remove something it would fail. This enforces the rule that only
     * the Model changes its own data — every real change goes through add()/clear(),
     * which the Controller calls. It makes the flow of changes easy to follow.
     */
    public List<int[]> getPoints() {
        return Collections.unmodifiableList(points);
    }
}
