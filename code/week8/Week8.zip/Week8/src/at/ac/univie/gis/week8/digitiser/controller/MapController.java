package at.ac.univie.gis.week8.digitiser.controller;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import at.ac.univie.gis.week8.digitiser.io.WktFile;
import at.ac.univie.gis.week8.digitiser.model.FeatureType;
import at.ac.univie.gis.week8.digitiser.model.GeoFeature;
import at.ac.univie.gis.week8.digitiser.model.GeoReference;
import at.ac.univie.gis.week8.digitiser.model.MapModel;
import at.ac.univie.gis.week8.digitiser.view.MapView;

/**
 * CONTROLLER (the "C" in MVC) — and the program's entry point.
 *
 * In MVC the Controller is the glue between the Model (the data) and the View
 * (what the user sees). It never stores the geometry itself and it never paints
 * pixels itself; instead it:
 *
 *   1. LISTENS to the View for user input (mouse clicks, button presses),
 *   2. UPDATES the Model in response,
 *   3. asks the View to REPAINT so the change becomes visible.
 *
 * That three-step cycle is the heart of every interactive program. For a single
 * map click it looks like this:
 *
 *   click  ->  convert pixel to lon/lat  ->  model.addVertex(...)  ->  view.repaint()
 *
 * This class also owns main(), so it is responsible for building the three MVC
 * objects, wiring them together, loading the basemap, and showing the window.
 */
public class MapController {

    // ---- Configuration constants -------------------------------------------

    // Geographic box of data/campus.png — the OpenStreetMap tiles stitched
    // around the NIG building (Universitaetsstrasse 7). The basemap image and
    // this box describe the SAME rectangle of the world, which is what lets a
    // pixel click be turned into a real longitude/latitude. If you regenerate
    // the basemap for a different area, update these four numbers to match.
    private static final double MIN_LON = 16.351776, MIN_LAT = 48.212778;
    private static final double MAX_LON = 16.360016, MAX_LAT = 48.216438;

    private static final String BASEMAP_PATH = "data/campus.png";
    private static final String SAVE_DIR = "data";
    private static final String SAVE_BASE = "features"; // -> features_001.wkt, ...

    // ---- The three things the controller coordinates ------------------------
    // These are passed IN through the constructor (rather than created here) so
    // that the controller depends only on what it is given. This makes the parts
    // easy to swap or test independently.
    private final MapModel model;
    private final MapView view;
    private final GeoReference geo;
    private final JLabel status; // the little text line at the bottom of the window

    public MapController(MapModel model, MapView view, GeoReference geo, JLabel status) {
        this.model = model;
        this.view = view;
        this.geo = geo;
        this.status = status;

        // Attach a mouse listener to the VIEW. A MouseAdapter is a helper class
        // that already provides empty versions of all the mouse methods, so we
        // only override the one we care about (mouseClicked). The "new
        // MouseAdapter() { ... }" syntax creates an anonymous subclass on the spot.
        view.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // e.getX()/e.getY() are PIXEL coordinates on the panel. We ask the
                // GeoReference to turn them into world coordinates (lon, lat) here,
                // in the controller, so the model only ever stores lon/lat and
                // never has to know about pixels or the screen.
                double[] world = geo.pixelToWorld(e.getX(), e.getY());

                model.addVertex(world[0], world[1]);   // step 2: update the model

                status.setText(String.format(
                        "Added vertex at (%.5f, %.5f). Current points: %d",
                        world[0], world[1],
                        model.getCurrent() == null ? 0 : model.getCurrent().size()));

                view.repaint();                         // step 3: ask for a redraw
            }
        });
    }

    /**
     * Build the window, create the buttons, wire each one to an action, and show
     * everything. Each button's ActionListener is written as a lambda
     * "e -> ..." which is short for "when clicked, run this code".
     */
    public void start() {
        // The two "New ..." buttons just tell the model which kind of feature the
        // next clicks belong to.
        JButton route = new JButton("New Route");
        route.addActionListener(e -> startFeature(FeatureType.ROUTE));

        JButton footprint = new JButton("New Footprint");
        footprint.addActionListener(e -> startFeature(FeatureType.FOOTPRINT));

        // "Finish" banks the feature currently being drawn into the finished list.
        JButton finish = new JButton("Finish");
        finish.addActionListener(e -> {
            model.finishCurrent();
            status.setText("Feature finished. Total features: "
                    + model.getFinished().size());
            view.repaint();
        });

        JButton save = new JButton("Save");
        save.addActionListener(e -> save());

        JButton load = new JButton("Load");
        load.addActionListener(e -> load());

        JButton clear = new JButton("Clear");
        clear.addActionListener(e -> {
            model.clearAll();
            status.setText("Cleared.");
            view.repaint();
        });

        // A JPanel with the default FlowLayout simply lays the buttons out in a row.
        JPanel controls = new JPanel();
        controls.add(route);
        controls.add(footprint);
        controls.add(finish);
        controls.add(save);
        controls.add(load);
        controls.add(clear);

        // BorderLayout lets us place components in five regions. We use three:
        // the buttons on top (NORTH), the map in the middle (CENTER), and the
        // status text at the bottom (SOUTH).
        JFrame frame = new JFrame("Campus Digitiser");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // closing the window ends the program
        frame.setLayout(new BorderLayout());
        frame.add(view, BorderLayout.CENTER);
        frame.add(controls, BorderLayout.NORTH);
        frame.add(status, BorderLayout.SOUTH);
        frame.pack();              // size the window to fit its contents
        frame.setVisible(true);
    }

    /** Start a fresh feature of the given type (any in-progress one is banked first). */
    private void startFeature(FeatureType type) {
        model.finishCurrent();          // bank whatever was in progress
        model.setNextType(type);
        status.setText("Digitising a " + type + " - click to add vertices.");
    }

    /**
     * Write the finished features to a file. This is the WRITING side of the
     * week's file-I/O story (Slide 13): the actual writing happens in
     * WktFile.save; the controller only decides WHERE to write and how to react
     * if it fails.
     */
    private void save() {
        // Include any in-progress feature so the user doesn't lose it on save.
        model.finishCurrent();
        new File(SAVE_DIR).mkdirs(); // create the data/ folder if it isn't there yet

        // Each save goes to the next free number so earlier saves are kept.
        String path = nextSavePath();
        try {
            WktFile.save(model.getFinished(), path);
            status.setText("Saved " + model.getFinished().size()
                    + " feature(s) to " + path);
        } catch (IOException ex) {
            // Writing can fail for real-world reasons (no permission, disk full).
            // The controller has the UI, so it is the right place to tell the user.
            status.setText("Save failed: " + ex.getMessage());
        }
        view.repaint();
    }

    /**
     * Read features back from the most recent numbered save. This is the READING
     * side (Slide 12); WktFile.load does the line-by-line reading and quietly
     * skips any corrupt line.
     */
    private void load() {
        String path = latestSavePath();
        if (path == null) {
            status.setText("No saved file found in " + SAVE_DIR + "/.");
            return;
        }
        List<GeoFeature> loaded = WktFile.load(path);
        model.replaceFinished(loaded);
        status.setText("Loaded " + loaded.size() + " feature(s) from " + path);
        view.repaint();
    }

    /** Build the path for the NEXT save: one higher than the highest existing number. */
    private String nextSavePath() {
        // "%03d" pads the number to 3 digits (1 -> "001"), so the files sort
        // nicely both in the file browser and alphabetically.
        return String.format("%s/%s_%03d.wkt", SAVE_DIR, SAVE_BASE, highestSaveNumber() + 1);
    }

    /** Path of the most recent save (data/features_{max}.wkt), or null if there is none. */
    private String latestSavePath() {
        int n = highestSaveNumber();
        return n == 0 ? null : String.format("%s/%s_%03d.wkt", SAVE_DIR, SAVE_BASE, n);
    }

    /**
     * Look through SAVE_DIR for files called features_NNN.wkt and return the
     * highest NNN found (or 0 if none exist yet). listFiles takes a filter that
     * is asked, for every file, "should I include this one?".
     */
    private int highestSaveNumber() {
        File[] files = new File(SAVE_DIR).listFiles(
                (dir, name) -> name.startsWith(SAVE_BASE + "_") && name.endsWith(".wkt"));
        int max = 0;
        if (files != null) { // listFiles returns null if the folder doesn't exist
            for (File f : files) {
                String name = f.getName();
                // Cut "features_" off the front and ".wkt" off the back, leaving the digits.
                String digits = name.substring((SAVE_BASE + "_").length(),
                                                name.length() - ".wkt".length());
                try {
                    max = Math.max(max, Integer.parseInt(digits));
                } catch (NumberFormatException ignored) {
                    // A "features_*.wkt" whose middle part isn't a number: just skip it.
                }
            }
        }
        return max;
    }

    /**
     * Load the basemap with ImageIO (Slides 15-16). A missing or unreadable file
     * must NOT crash the program: we report it and return null, and the View
     * paints a fallback grid instead. This is the "fallback" recovery pattern
     * from Slide 22.
     */
    private static BufferedImage loadBasemap(String path) {
        try {
            File file = new File(path);
            if (!file.exists()) {
                System.err.println("Basemap " + path + " not found; using fallback.");
                return null;
            }
            return ImageIO.read(file); // decodes the PNG into a grid of pixels in memory
        } catch (IOException e) {
            System.err.println("Could not read basemap (" + e.getMessage()
                    + "); using fallback.");
            return null;
        }
    }

    /**
     * Program entry point. This is the ONE place that knows about all three MVC
     * parts at once: it creates them, hands the dependencies to each, and starts.
     */
    public static void main(String[] args) {
        // Load the picture first; it may be null, and that is fine.
        BufferedImage basemap = loadBasemap(BASEMAP_PATH);

        // The georeference maps the panel's pixel area onto the campus bounding
        // box, so a click anywhere on the 900x600 panel becomes a lon/lat.
        GeoReference geo = new GeoReference(MapView.WIDTH, MapView.HEIGHT,
                MIN_LON, MIN_LAT, MAX_LON, MAX_LAT);

        // Create the three layers. Notice the dependency direction: the View is
        // given the Model (it reads it to draw); the Controller is given all of
        // them (it coordinates). The Model is given nothing — it is independent.
        MapModel model = new MapModel();
        MapView view = new MapView(model, geo, basemap);
        JLabel status = new JLabel("Pick New Route or New Footprint, then click to digitise.");

        MapController controller = new MapController(model, view, geo, status);
        controller.start();
    }
}
