package at.ac.univie.gis.week8.digitiser.model;

/**
 * MODEL helper — converts between image PIXEL coordinates and WORLD coordinates
 * (longitude / latitude). Pure maths, no GUI imports.
 *
 * This is the same screen/world mismatch you met in Week 7's GeoSnap example,
 * but simpler: we assume the basemap image covers an axis-aligned rectangular
 * geographic box, and we interpolate linearly inside it. (In real GIS, pairing a
 * raster image with the box it covers is called a "world file".)
 *
 * The crucial detail is that the Y axis FLIPS: on an image, pixel y grows
 * DOWNWARDS (row 0 is the top), but latitude grows UPWARDS (north is up). So the
 * top row of pixels corresponds to the MAXIMUM latitude.
 *
 * "Interpolate" here just means: if a click is, say, 30% of the way across the
 * image, its longitude is 30% of the way from minLon to maxLon.
 */
public class GeoReference {

    private final int imageWidth;
    private final int imageHeight;
    private final double minLon;
    private final double minLat;
    private final double maxLon;
    private final double maxLat;

    public GeoReference(int imageWidth, int imageHeight,
                        double minLon, double minLat, double maxLon, double maxLat) {
        this.imageWidth = imageWidth;
        this.imageHeight = imageHeight;
        this.minLon = minLon;
        this.minLat = minLat;
        this.maxLon = maxLon;
        this.maxLat = maxLat;
    }

    /**
     * Pixel (px, py) -> world {lon, lat}. Used when the user clicks: we know
     * where on screen they clicked and want the real coordinate there.
     */
    public double[] pixelToWorld(int px, int py) {
        // px / width is the fraction across (0 at left, 1 at right).
        double lon = minLon + (px / (double) imageWidth) * (maxLon - minLon);
        // py / height is the fraction down; we subtract from maxLat because the
        // top of the image is the northern (maximum) latitude.
        double lat = maxLat - (py / (double) imageHeight) * (maxLat - minLat);
        return new double[]{lon, lat};
    }

    /**
     * World (lon, lat) -> pixel {px, py}. The inverse of pixelToWorld; used when
     * drawing, to place a stored lon/lat back onto the screen.
     */
    public int[] worldToPixel(double lon, double lat) {
        int px = (int) Math.round((lon - minLon) / (maxLon - minLon) * imageWidth);
        int py = (int) Math.round((maxLat - lat) / (maxLat - minLat) * imageHeight);
        return new int[]{px, py};
    }
}
