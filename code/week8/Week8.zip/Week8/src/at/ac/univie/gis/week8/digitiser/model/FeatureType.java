package at.ac.univie.gis.week8.digitiser.model;

/**
 * The kind of feature the user is digitising.
 *
 * A ROUTE is an open polyline (e.g. your walk to campus) and is saved as a WKT
 * LINESTRING. A FOOTPRINT is a closed ring (e.g. the outline of the NIG building)
 * and is saved as a WKT POLYGON.
 *
 * This is the same enum idea from Week 4: a small, type-safe set of named
 * constants. What is new here is that each constant carries a little data of its
 * own — its WKT keyword and whether it is a closed ring. Enums in Java are real
 * objects, so they can have fields, a constructor, and methods like any class.
 */
public enum FeatureType {

    // Each constant is created by calling the constructor below with its values.
    ROUTE("LINESTRING", false),
    FOOTPRINT("POLYGON", true);

    private final String wktKeyword;
    private final boolean closedRing;

    // The enum constructor is always private; it runs once for each constant above.
    FeatureType(String wktKeyword, boolean closedRing) {
        this.wktKeyword = wktKeyword;
        this.closedRing = closedRing;
    }

    /** "LINESTRING" or "POLYGON" — the WKT geometry keyword for this type. */
    public String wktKeyword() {
        return wktKeyword;
    }

    /** A polygon must repeat its first point at the end to close; a line must not. */
    public boolean isClosedRing() {
        return closedRing;
    }
}
