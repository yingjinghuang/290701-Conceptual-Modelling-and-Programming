package at.ac.univie.gis.week8.sir;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

/**
 * VIEW — a second view of the same model: a live line chart of how many people
 * are Susceptible / Infectious / Recovered on each simulated day.
 *
 * The controller calls addSample(...) once per day; this panel just stores the
 * numbers and draws three curves. Watching the RED (Infectious) curve is how you
 * literally SEE whether a stay-at-home order "flattens the curve".
 *
 * Fully provided — you do not change this for the assignment. (It is also a nice
 * illustration of MVC: one model, drawn by two different views at once.) To make
 * it appear, include it in your window layout in SirController (Task 4).
 */
public class SirChart extends JPanel {

    // Each entry is one day's counts: {susceptible, infectious, recovered}.
    private final List<int[]> history = new ArrayList<>();
    private int maxTotal = 1; // largest population seen, used to scale the Y axis

    public SirChart() {
        setPreferredSize(new Dimension(300, 640)); // match the 80x8 grid height
        setBackground(Color.WHITE);
    }

    /** Record one day's counts (called by the controller after each step). */
    public void addSample(int susceptible, int infectious, int recovered) {
        history.add(new int[]{susceptible, infectious, recovered});
        maxTotal = Math.max(maxTotal, susceptible + infectious + recovered);
    }

    /** Forget all history (called on Reset). */
    public void clear() {
        history.clear();
        maxTotal = 1;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);

        int left = 40, right = 12, top = 28, bottom = 24;
        int plotW = getWidth() - left - right;
        int plotH = getHeight() - top - bottom;

        // Title, axes box, and a small colour legend.
        g2d.setColor(Color.DARK_GRAY);
        g2d.drawString("Population over time (days)", left, 18);
        g2d.setColor(new Color(200, 200, 200));
        g2d.drawRect(left, top, plotW, plotH);
        drawLegend(g2d, left + 6, top + 12);

        if (history.size() < 2) {
            return; // need at least two points to draw a line
        }

        // Three curves. Draw Infectious last so it sits on top.
        drawSeries(g2d, 0, new Color(90, 170, 90),   left, top, plotW, plotH); // S
        drawSeries(g2d, 2, new Color(140, 150, 170), left, top, plotW, plotH); // R
        drawSeries(g2d, 1, new Color(220, 70, 70),   left, top, plotW, plotH); // I
    }

    /** Draw one series (field 0=S, 1=I, 2=R) as a polyline across the plot. */
    private void drawSeries(Graphics2D g2d, int field, Color color,
                            int left, int top, int plotW, int plotH) {
        g2d.setColor(color);
        g2d.setStroke(new BasicStroke(field == 1 ? 2.5f : 1.5f));
        int n = history.size();
        for (int i = 1; i < n; i++) {
            // x: spread all samples evenly across the width.
            int x0 = left + (int) ((i - 1) / (double) (n - 1) * plotW);
            int x1 = left + (int) ( i      / (double) (n - 1) * plotW);
            // y: 0 at the bottom, maxTotal at the top (note: screen y grows down).
            int y0 = top + plotH - (int) (history.get(i - 1)[field] / (double) maxTotal * plotH);
            int y1 = top + plotH - (int) (history.get(i)[field]     / (double) maxTotal * plotH);
            g2d.drawLine(x0, y0, x1, y1);
        }
    }

    private void drawLegend(Graphics2D g2d, int x, int y) {
        g2d.setColor(new Color(90, 170, 90));   g2d.fillRect(x, y, 10, 10);
        g2d.setColor(Color.DARK_GRAY);           g2d.drawString("S", x + 14, y + 10);
        g2d.setColor(new Color(220, 70, 70));    g2d.fillRect(x + 34, y, 10, 10);
        g2d.setColor(Color.DARK_GRAY);           g2d.drawString("I", x + 48, y + 10);
        g2d.setColor(new Color(140, 150, 170));  g2d.fillRect(x + 64, y, 10, 10);
        g2d.setColor(Color.DARK_GRAY);           g2d.drawString("R", x + 78, y + 10);
    }
}
