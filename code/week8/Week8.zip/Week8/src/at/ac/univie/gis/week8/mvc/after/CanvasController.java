package at.ac.univie.gis.week8.mvc.after;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * CONTROLLER (the "C" in MVC) — Slide 8. Also the program's entry point.
 *
 * The Controller is the glue between Model and View. It listens to the View for
 * input, updates the Model, and asks the View to repaint. It owns no data and
 * draws nothing itself.
 *
 * Watch the click cycle in mouseClicked() — it is the whole of interactive
 * programming in two lines:
 *   listen -> update the model -> ask the view to repaint.
 *
 * Compare clear() with the monolithic "before" version: here the Controller
 * calls a model METHOD (model.clear()); it never reaches into the model's
 * internal list the way MonolithicCanvas did with canvas.points.clear().
 */
public class CanvasController {

    private final PointsModel model;
    private final CanvasView view;

    public CanvasController(PointsModel model, CanvasView view) {
        this.model = model;
        this.view = view;

        // Listen to the VIEW for clicks. MouseAdapter provides empty versions of
        // all the mouse methods so we only override the one we need.
        view.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                model.add(e.getX(), e.getY()); // 1. update the model
                view.repaint();                 // 2. ask the view to refresh
            }
        });
    }

    /** Build the window, wire the Clear button, and show it. */
    public void start() {
        JButton clear = new JButton("Clear");
        clear.addActionListener(e -> {
            model.clear();   // go through the model's public method...
            view.repaint();  // ...then refresh the screen
        });

        JPanel controls = new JPanel();
        controls.add(clear);

        JFrame frame = new JFrame("MVC Canvas (after): click to draw");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.add(view, BorderLayout.CENTER);
        frame.add(controls, BorderLayout.SOUTH);
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        // This is the only place that knows about all three parts at once: it
        // creates them, connects them, and starts the program. The View is given
        // the Model (it reads it); the Controller is given both (it coordinates).
        PointsModel model = new PointsModel();
        CanvasView view = new CanvasView(model);
        CanvasController controller = new CanvasController(model, view);
        controller.start();
    }
}
