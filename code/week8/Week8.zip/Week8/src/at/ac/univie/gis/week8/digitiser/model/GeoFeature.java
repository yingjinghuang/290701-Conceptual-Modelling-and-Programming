package at.ac.univie.gis.week8.digitiser.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * MODEL — one digitised feature: a type (route or footprint) plus a list of
 * vertices in WORLD coordinates (longitude, latitude).
 *
 * This is pure data and logic with no GUI imports, which is the iron rule for the
 * Model layer (Slide 6). The only "clever" part is converting to and from WKT.
 *
 * WKT (Well-Known Text) is the standard text format GIS tools use for geometry.
 * A route becomes one line:
 *
 *     LINESTRING (16.357 48.213, 16.359 48.215, 16.361 48.214)
 *
 * and a building footprint becomes a closed ring (first point repeated at the end):
 *
 *     POLYGON ((16.357 48.213, 16.359 48.215, 16.361 48.214, 16.357 48.213))
 *
 * Producing these strings is the WRITING half of the week (Slide 13); reading
 * them back is the READING half (Slide 12).
 */
public class GeoFeature {

    private final FeatureType type;

    /** Each vertex is a two-element array: {longitude, latitude}. */
    private final List<double[]> vertices = new ArrayList<>();

    public GeoFeature(FeatureType type) {
        this.type = type;
    }

    public FeatureType getType() {
        return type;
    }

    public int size() {
        return vertices.size();
    }

    public List<double[]> getVertices() {
        return vertices;
    }

    /** Append a vertex given in world coordinates (longitude, latitude). */
    public void addVertex(double lon, double lat) {
        vertices.add(new double[]{lon, lat});
    }

    /**
     * Turn this feature into a single line of WKT.
     *
     * We build the comma-separated coordinate list with a StringBuilder (cheaper
     * than repeatedly using "+" on strings inside a loop). For a polygon we add
     * the first vertex again at the end to "close the ring", and wrap the
     * coordinates in a second pair of parentheses, as the WKT POLYGON syntax
     * requires.
     */
    public String toWkt() {
        StringBuilder coords = new StringBuilder();
        for (int i = 0; i < vertices.size(); i++) {
            if (i > 0) {
                coords.append(", "); // separator between pairs, but not before the first
            }
            coords.append(formatPair(vertices.get(i)));
        }

        if (type.isClosedRing() && vertices.size() > 0) {
            coords.append(", ").append(formatPair(vertices.get(0))); // repeat first point
            return type.wktKeyword() + " ((" + coords + "))";        // POLYGON ((...))
        }
        return type.wktKeyword() + " (" + coords + ")";              // LINESTRING (...)
    }

    /**
     * Format one "lon lat" pair with 6 decimal places. We force Locale.US so the
     * decimal separator is always a dot ("16.357"), never a comma ("16,357") as
     * some regional settings would otherwise produce — a comma would corrupt the
     * WKT, since commas separate the pairs.
     */
    private static String formatPair(double[] p) {
        return String.format(Locale.US, "%.6f %.6f", p[0], p[1]);
    }

    /**
     * Parse one line of WKT back into a GeoFeature — the inverse of toWkt().
     *
     * It is deliberately small and strict: anything it cannot understand makes it
     * throw IllegalArgumentException. The file loader (WktFile.load) catches that
     * and decides to skip the line and carry on (the "skip" recovery pattern,
     * Slide 22). Keeping the "what to do about a bad line" decision OUT of here
     * keeps this method simple and reusable.
     *
     * @param line one line of WKT text
     * @return the parsed feature
     * @throws IllegalArgumentException if the line is not valid WKT we understand
     */
    public static GeoFeature parseWkt(String line) {
        String text = line.trim();

        // Decide the type from the keyword at the start of the line.
        FeatureType type;
        if (text.startsWith("LINESTRING")) {
            type = FeatureType.ROUTE;
        } else if (text.startsWith("POLYGON")) {
            type = FeatureType.FOOTPRINT;
        } else {
            throw new IllegalArgumentException("Unknown geometry: " + line);
        }

        // Take everything between the first '(' and the last ')'. For a POLYGON
        // that still leaves the inner "(...)", so we strip any remaining
        // parentheses to be left with just the coordinate list.
        int open = text.indexOf('(');
        int close = text.lastIndexOf(')');
        if (open < 0 || close <= open) {
            throw new IllegalArgumentException("Malformed WKT: " + line);
        }
        String inner = text.substring(open + 1, close).replace("(", "").replace(")", "").trim();

        GeoFeature feature = new GeoFeature(type);
        // Split the list on commas, then split each "lon lat" pair on whitespace.
        for (String pair : inner.split(",")) {
            String[] xy = pair.trim().split("\\s+"); // "\\s+" = one or more spaces
            if (xy.length != 2) {
                throw new IllegalArgumentException("Bad coordinate pair: " + pair);
            }
            // Double.parseDouble throws NumberFormatException on garbage; that is
            // an IllegalArgumentException, so the loader's catch handles it too.
            feature.addVertex(Double.parseDouble(xy[0]), Double.parseDouble(xy[1]));
        }
        return feature;
    }
}
