package at.ac.univie.gis.week8.mvc.after;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.List;

import javax.swing.JPanel;

/**
 * VIEW (the "V" in MVC) — Slide 7.
 *
 * The View's only job is to DRAW the model. It is given a reference to the model
 * and reads from it; it does not own the data and it does not handle input (no
 * mouse listener, no buttons live here — those are the Controller's job).
 *
 * Keeping the View this thin means one model could be shown by several different
 * views at once (a canvas, a table, a chart), each just reading the same data.
 */
public class CanvasView extends JPanel {

    private static final int DOT_RADIUS = 6;

    // The View keeps a reference to the model so it can read it while painting.
    private final PointsModel model;

    public CanvasView(PointsModel model) {
        this.model = model;
        setPreferredSize(new Dimension(600, 500));
        setBackground(Color.WHITE);
    }

    /**
     * Swing calls this whenever the panel must be (re)drawn — never call it
     * directly. After the data changes, the Controller calls repaint(), and Swing
     * then calls this method. Each call redraws everything from the current model
     * state, so the screen always reflects the latest data.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // clears the panel first

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);

        // Read the data from the model — the View never stores it itself.
        List<int[]> points = model.getPoints();

        // Connect consecutive points with line segments.
        g2d.setColor(Color.BLUE);
        for (int i = 1; i < points.size(); i++) {
            int[] a = points.get(i - 1);
            int[] b = points.get(i);
            g2d.drawLine(a[0], a[1], b[0], b[1]);
        }

        // Draw a red dot at each point. fillOval takes the top-left corner, so we
        // offset by the radius to centre each dot on its point.
        g2d.setColor(Color.RED);
        for (int[] p : points) {
            g2d.fillOval(p[0] - DOT_RADIUS, p[1] - DOT_RADIUS,
                         DOT_RADIUS * 2, DOT_RADIUS * 2);
        }

        g2d.setColor(Color.DARK_GRAY);
        g2d.drawString("Click anywhere to add a vertex. Points: " + model.size(),
                       10, 20);
    }
}
