package at.ac.univie.gis.week8.digitiser.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import at.ac.univie.gis.week8.digitiser.model.GeoFeature;

/**
 * Reads and writes digitised features as text — one WKT geometry per line.
 *
 * This single class is where the whole week's file-I/O and exception story comes
 * together:
 *
 *   - WRITING (Slide 13): a FileWriter wrapped in a BufferedWriter, inside a
 *     "try-with-resources" block so the file is always flushed and closed.
 *   - READING (Slide 12): a FileReader wrapped in a BufferedReader, calling
 *     readLine() in a loop until it returns null (end of file).
 *   - EXCEPTIONS (Slides 19-22): a missing file falls back to an empty list, and
 *     a single broken line is logged and skipped instead of sinking the whole
 *     load.
 *
 * There is no Swing anywhere here — this is plain library code you could reuse or
 * unit-test on its own.
 */
public final class WktFile {

    // This class is just a holder for two static methods, so we hide the
    // constructor: nobody should ever write "new WktFile()".
    private WktFile() {
    }

    /**
     * Write every feature to 'path', one WKT line each.
     *
     * The "try (BufferedWriter writer = ...) { ... }" form is called
     * try-with-resources: anything declared in those parentheses is closed
     * automatically when the block ends, even if an exception is thrown. It is
     * the modern, safer replacement for closing the file by hand in a finally
     * block.
     *
     * We do NOT catch IOException here. Instead we declare "throws IOException"
     * and let it travel up to the controller, which has the user interface and
     * can decide how to report the problem.
     *
     * @param features the geometries to write
     * @param path     the file to create or overwrite
     * @throws IOException if the file cannot be written
     */
    public static void save(List<GeoFeature> features, String path) throws IOException {
        // FileWriter opens the file for writing characters; we pass UTF-8
        // explicitly (Slide 14) so the file is encoded predictably. BufferedWriter
        // wraps it for efficiency and gives us the handy newLine() method.
        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter(path, StandardCharsets.UTF_8))) {
            for (GeoFeature feature : features) {
                writer.write(feature.toWkt()); // ask each feature for its WKT text
                writer.newLine();              // end the line
            }
        } // <- writer.close() happens here automatically
    }

    /**
     * Read features back from 'path'. Returns a list (never null); if anything
     * goes wrong the list just contains whatever could be read successfully.
     *
     * Two recovery patterns from Slide 22 are visible here:
     *   - FALLBACK: if the file is missing or unreadable we log it and return an
     *     empty list rather than crashing.
     *   - SKIP: if one line is corrupt we log it, skip it, and keep reading the
     *     rest — one bad row must not lose all the good ones.
     *
     * @param path the file to read
     * @return the features that were read (possibly empty)
     */
    public static List<GeoFeature> load(String path) {
        List<GeoFeature> features = new ArrayList<>();

        // try-with-resources again: the reader is closed automatically.
        try (BufferedReader reader = new BufferedReader(
                new FileReader(path, StandardCharsets.UTF_8))) {

            String line;
            int lineNumber = 0;
            // readLine() returns one line at a time, or null at end of file.
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (line.isBlank()) {
                    continue; // ignore empty lines
                }
                try {
                    features.add(GeoFeature.parseWkt(line));
                } catch (IllegalArgumentException bad) {
                    // SKIP pattern: this one line couldn't be parsed, so report it
                    // and move on. (NumberFormatException, thrown when a coordinate
                    // isn't a number, is a subclass of IllegalArgumentException, so
                    // this single catch covers that case too.)
                    System.err.println("Skipping bad line " + lineNumber
                            + ": " + bad.getMessage());
                }
            }
        } catch (IOException e) {
            // FALLBACK pattern: no file (or it could not be opened) -> empty list.
            System.err.println("Could not read " + path
                    + " (" + e.getMessage() + "); starting empty.");
        }
        return features;
    }
}
