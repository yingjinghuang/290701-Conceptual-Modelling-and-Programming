package at.ac.univie.gis.week8.sir;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * MODEL — the epidemic simulation itself. No Swing, no drawing: just the grid,
 * the rules, and the parameters. (The Model holds data and logic only.)
 *
 * The world is a square grid. Every cell is either EMPTY or holds one person who
 * is Susceptible, Infectious, or Recovered. Each simulated day (one step) does:
 *   1. infection + recovery  — which YOU implement with the copy-and-swap pattern,
 *   2. movement              — people wander into nearby empty cells (provided),
 * unless a stay-at-home order keeps them put.
 *
 * ==========================================================================
 *  YOUR JOB: complete the three methods marked "TODO":
 *     countInfectiousNeighbours(...)   nextState(...)   step()
 *  Everything else in this file is provided for you.
 * ==========================================================================
 */
public class SirModel {

    // Cell states. We use plain ints so the whole grid is one simple int[][].
    public static final int EMPTY = 0;
    public static final int S = 1; // Susceptible (healthy, can be infected)
    public static final int I = 2; // Infectious (sick, spreading)
    public static final int R = 3; // Recovered (immune, no longer spreading)

    private final int size;
    private int[][] grid;
    private final Random random = new Random();

    // Parameters, all between 0 and 1, controlled by the GUI sliders.
    private double infectionRate = 0.30; // beta:  chance one infectious neighbour infects a susceptible
    private double recoveryRate  = 0.08; // gamma: chance an infectious person recovers each day
    private double stayHome      = 0.00; // fraction of people who stay home (do not move) each day
    private double density       = 0.30; // fraction of cells occupied when the grid is (re)seeded

    public SirModel(int size) {
        this.size = size;
        reset();
    }

    // ------------------------------------------------------------------ seeding

    /** Re-create the population: fill cells to 'density' with S, then infect a few. */
    public void reset() {
        grid = new int[size][size];
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                if (random.nextDouble() < density) {
                    grid[r][c] = S;
                }
            }
        }
        int seeds = Math.max(1, (int) (size * size * density * 0.01));
        int placed = 0;
        while (placed < seeds) {
            int r = random.nextInt(size);
            int c = random.nextInt(size);
            if (grid[r][c] == S) {
                grid[r][c] = I;
                placed++;
            }
        }
    }

    // -------------------------------------------------------------- the daily step

    /**
     * TODO (3) — Advance the simulation by one day, using COPY-AND-SWAP.
     *
     * Infection and recovery must be computed from ONE snapshot of the grid, so:
     *   1. make a new, empty grid:   int[][] next = new int[size][size];
     *   2. for every cell (r, c) of the CURRENT grid:
     *        - if it is EMPTY, leave next[r][c] EMPTY;
     *        - otherwise set next[r][c] = nextState(current,
     *                                               countInfectiousNeighbours(r, c));
     *   3. swap the new grid in:     grid = next;
     *
     * Why a new grid? If you wrote the new states back into the same grid you are
     * reading, a cell infected early in the pass would wrongly affect its
     * neighbours later in the SAME day. Copy-and-swap updates everyone together.
     *
     * Keep the move() call at the very end so people move after the day's
     * infections and recoveries are decided.
     */
    public void step() {
        // --- TODO: your copy-and-swap code goes here ---

        move(); // movement is provided for you — keep this call at the END of step()
    }

    /**
     * TODO (1) — Count how many of the 8 surrounding cells (the Moore
     * neighbourhood) are Infectious (state == I).
     *
     * Loop over dr in -1..1 and dc in -1..1:
     *   - skip the cell itself (dr == 0 && dc == 0);
     *   - skip neighbours that fall outside the grid (row/col < 0 or >= size);
     *   - count the ones where grid[...][...] == I.
     * (You wrote almost exactly this method for the Game of Life.)
     */
    public int countInfectiousNeighbours(int row, int col) {
        // --- TODO: replace this with your neighbour-counting code ---
        return 0;
    }

    /**
     * TODO (2) — Return the cell's NEXT state, given its current state and how
     * many infectious neighbours it has. This is the SIR rule:
     *
     *   - if current == S: it becomes I with probability
     *         1.0 - Math.pow(1.0 - infectionRate, infectiousNeighbours)
     *     and otherwise stays S.   (use:  random.nextDouble() < probability)
     *   - if current == I: it becomes R with probability recoveryRate, else stays I.
     *   - if current == R: it stays R.
     */
    public int nextState(int current, int infectiousNeighbours) {
        // --- TODO: replace this with the SIR transition rule ---
        return current;
    }

    // --------------------------------------------------------------- movement (given)

    /**
     * Move people around. Each person, unless they stay home, hops into a random
     * empty neighbouring cell. We shuffle the order so nobody is systematically
     * favoured, and mark cells as "settled" so a person is never moved twice in
     * one day. (Provided — you do not need to change this.)
     */
    private void move() {
        List<int[]> people = new ArrayList<>();
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                if (grid[r][c] != EMPTY) people.add(new int[]{r, c});
            }
        }
        Collections.shuffle(people, random);

        boolean[][] settled = new boolean[size][size];
        for (int[] person : people) {
            int r = person[0], c = person[1];
            if (settled[r][c] || grid[r][c] == EMPTY) continue;

            if (random.nextDouble() < stayHome) {
                settled[r][c] = true;
                continue;
            }

            List<int[]> empties = new ArrayList<>();
            for (int dr = -1; dr <= 1; dr++) {
                for (int dc = -1; dc <= 1; dc++) {
                    if (dr == 0 && dc == 0) continue;
                    int nr = r + dr, nc = c + dc;
                    if (nr < 0 || nr >= size || nc < 0 || nc >= size) continue;
                    if (grid[nr][nc] == EMPTY && !settled[nr][nc]) empties.add(new int[]{nr, nc});
                }
            }
            if (empties.isEmpty()) {
                settled[r][c] = true;
                continue;
            }
            int[] target = empties.get(random.nextInt(empties.size()));
            grid[target[0]][target[1]] = grid[r][c];
            grid[r][c] = EMPTY;
            settled[target[0]][target[1]] = true;
        }
    }

    // ------------------------------------------------------------------- accessors

    /** Count how many cells are in the given state (for the S/I/R readout). */
    public int count(int state) {
        int n = 0;
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                if (grid[r][c] == state) n++;
            }
        }
        return n;
    }

    public int getSize()      { return size; }
    public int[][] getGrid()  { return grid; }

    public void setInfectionRate(double v) { infectionRate = v; }
    public void setRecoveryRate(double v)  { recoveryRate = v; }
    public void setStayHome(double v)      { stayHome = v; }
    public void setDensity(double v)       { density = v; } // takes effect on the next reset()
}
