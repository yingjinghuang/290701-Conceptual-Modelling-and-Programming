package at.ac.univie.gis.week8.digitiser.view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.List;

import javax.swing.JPanel;

import at.ac.univie.gis.week8.digitiser.model.FeatureType;
import at.ac.univie.gis.week8.digitiser.model.GeoFeature;
import at.ac.univie.gis.week8.digitiser.model.GeoReference;
import at.ac.univie.gis.week8.digitiser.model.MapModel;

/**
 * VIEW (the "V" in MVC) — everything you see on screen.
 *
 * Its single job is to DRAW the current state of the model. Note what it does
 * NOT do:
 *   - it does not store the geometry (that lives in the MapModel),
 *   - it does not handle clicks or buttons (that is the controller's job).
 *
 * It only holds references it needs in order to draw: the model (what to draw),
 * the georeference (how to turn lon/lat into pixels), and the basemap image.
 *
 * Two ideas worth pointing out in the lecture:
 *   - Features are stored in WORLD coordinates (lon/lat), so before drawing each
 *     vertex the View asks the GeoReference to convert it back to a pixel.
 *   - If the basemap image is missing the View still works: it paints a plain
 *     fallback grid. That visible fallback is the exception-recovery idea from
 *     Slide 22, made literal on screen.
 */
public class MapView extends JPanel {

    // The fixed drawing size. They are public so the controller can build a
    // GeoReference that matches exactly this pixel area.
    public static final int WIDTH = 900;
    public static final int HEIGHT = 600;

    private static final int VERTEX_RADIUS = 4; // size of the little dots, in pixels

    private final MapModel model;
    private final GeoReference geo;
    private final BufferedImage basemap; // may be null -> draw the fallback grid instead

    public MapView(MapModel model, GeoReference geo, BufferedImage basemap) {
        this.model = model;
        this.geo = geo;
        this.basemap = basemap;
        setPreferredSize(new Dimension(WIDTH, HEIGHT)); // tells the window how big we want to be
        setBackground(Color.WHITE);
    }

    /**
     * Swing calls this method whenever the panel needs to be (re)drawn — never
     * call it yourself. To trigger a redraw after the data changes you call
     * repaint() (the controller does this), and Swing then calls paintComponent
     * for you. Every call starts from a clean slate and redraws everything from
     * the current model state.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // let JPanel clear the background first

        // Graphics2D is the richer drawing API; the object Swing hands us is
        // always really a Graphics2D, so we cast it to reach the better methods.
        Graphics2D g2d = (Graphics2D) g;

        // Rendering hints ask for higher-quality output:
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);          // smooth edges
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                             RenderingHints.VALUE_INTERPOLATION_BICUBIC); // crisp when the
                                                                          // large basemap is
                                                                          // scaled down

        drawBasemap(g2d);

        // Draw the already-finished features in the calm "inactive" colours...
        for (GeoFeature f : model.getFinished()) {
            drawFeature(g2d, f, false);
        }
        // ...then the feature currently being drawn, highlighted, on top.
        if (model.getCurrent() != null) {
            drawFeature(g2d, model.getCurrent(), true);
        }
    }

    /** Draw the loaded basemap stretched to fill the panel, or a labelled fallback grid. */
    private void drawBasemap(Graphics2D g2d) {
        if (basemap != null) {
            // Draw the image so it fills the whole panel (0,0) to (width,height).
            g2d.drawImage(basemap, 0, 0, getWidth(), getHeight(), null);
            return;
        }
        // No image was loaded: paint a light grid so the app is still usable and
        // the user understands why there is no map.
        g2d.setColor(new Color(238, 240, 242));
        g2d.fillRect(0, 0, getWidth(), getHeight());
        g2d.setColor(new Color(210, 214, 218));
        for (int x = 0; x < getWidth(); x += 50) {
            g2d.drawLine(x, 0, x, getHeight());
        }
        for (int y = 0; y < getHeight(); y += 50) {
            g2d.drawLine(0, y, getWidth(), y);
        }
        g2d.setColor(Color.GRAY);
        g2d.drawString("No basemap found - drop a PNG at data/campus.png "
                + "(showing fallback grid).", 12, 20);
    }

    /**
     * Draw one feature. 'active' is true for the feature currently being
     * digitised, which we draw thicker and in a warmer colour so it stands out.
     */
    private void drawFeature(Graphics2D g2d, GeoFeature feature, boolean active) {
        List<double[]> verts = feature.getVertices();
        if (verts.isEmpty()) {
            return; // nothing to draw yet
        }

        // The model stores lon/lat, but drawing needs pixels — so convert every
        // vertex once up front into two parallel arrays of x and y pixel values.
        int[] xs = new int[verts.size()];
        int[] ys = new int[verts.size()];
        for (int i = 0; i < verts.size(); i++) {
            int[] px = geo.worldToPixel(verts.get(i)[0], verts.get(i)[1]);
            xs[i] = px[0];
            ys[i] = px[1];
        }

        // A thicker pen for the feature being edited.
        g2d.setStroke(new BasicStroke(active ? 3f : 2f));

        if (feature.getType() == FeatureType.FOOTPRINT && verts.size() >= 3) {
            // A footprint with enough points is drawn as a filled polygon.
            // The 4th number in a Color is alpha (transparency) so the basemap
            // still shows through the fill.
            Polygon poly = new Polygon(xs, ys, xs.length);
            g2d.setColor(active ? new Color(230, 130, 40, 110)
                                : new Color(80, 160, 220, 90));
            g2d.fillPolygon(poly);
            g2d.setColor(active ? new Color(200, 90, 0) : new Color(20, 80, 140));
            g2d.drawPolygon(poly); // outline (this version closes the ring for us)
        } else {
            // A route (or a footprint with too few points) is just connected lines.
            g2d.setColor(active ? new Color(200, 90, 0) : new Color(20, 80, 140));
            for (int i = 1; i < xs.length; i++) {
                g2d.drawLine(xs[i - 1], ys[i - 1], xs[i], ys[i]);
            }
        }

        // Finally draw a dot on every vertex so the user can see the points.
        // fillOval is given the top-left corner, so we offset by the radius to
        // centre each dot on its vertex.
        g2d.setColor(active ? new Color(200, 90, 0) : new Color(20, 80, 140));
        for (int i = 0; i < xs.length; i++) {
            g2d.fillOval(xs[i] - VERTEX_RADIUS, ys[i] - VERTEX_RADIUS,
                         VERTEX_RADIUS * 2, VERTEX_RADIUS * 2);
        }
    }
}
