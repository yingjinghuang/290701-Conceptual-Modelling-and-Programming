package at.ac.univie.gis.week8.mvc.before;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * BEFORE — the single-class version (this is last week's CustomCanvasExample).
 *
 * One JPanel does EVERYTHING. Read it and notice the three different jobs all
 * tangled together in one file:
 *   - it HOLDS the data       (the list of points)             <- a Model job
 *   - it DRAWS it             (paintComponent)                 <- a View job
 *   - it HANDLES the input    (the MouseAdapter, the Clear button) <- a Controller job
 *
 * Two specific "code smells" to point at in class:
 *   1. Because data, drawing and input share one class, this file has three
 *      different reasons to change — edit the look and you risk the data, etc.
 *   2. The Clear button reaches STRAIGHT into the data with canvas.points.clear()
 *      (see main): the input code is mutating the "model's" internals directly.
 *
 * The package at.ac.univie.gis.week8.mvc.after takes this exact same program and
 * splits these three jobs into PointsModel / CanvasView / CanvasController. Run
 * both and you will see identical behaviour on screen.
 */
public class MonolithicCanvas extends JPanel {

    private static final int DOT_RADIUS = 6;

    // The data lives right here inside the panel (job 1).
    private final List<int[]> points = new ArrayList<>();

    public MonolithicCanvas() {
        setPreferredSize(new Dimension(600, 500));
        setBackground(Color.WHITE);

        // Input handling also lives here (job 3).
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                points.add(new int[]{e.getX(), e.getY()}); // update data
                repaint();                                  // ask for redraw
            }
        });
    }

    // Drawing also lives here (job 2).
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.setColor(Color.BLUE);
        for (int i = 1; i < points.size(); i++) {
            int[] a = points.get(i - 1);
            int[] b = points.get(i);
            g2d.drawLine(a[0], a[1], b[0], b[1]);
        }

        g2d.setColor(Color.RED);
        for (int[] p : points) {
            g2d.fillOval(p[0] - DOT_RADIUS, p[1] - DOT_RADIUS,
                         DOT_RADIUS * 2, DOT_RADIUS * 2);
        }

        g2d.setColor(Color.DARK_GRAY);
        g2d.drawString("Click anywhere to add a vertex. Points: " + points.size(),
                       10, 20);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Monolithic Canvas (before): click to draw");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MonolithicCanvas canvas = new MonolithicCanvas();

        JButton clear = new JButton("Clear");
        // SMELL: the button reaches directly into the panel's internal data list,
        // instead of asking through a method. The "after" version fixes this.
        clear.addActionListener(e -> {
            canvas.points.clear();
            canvas.repaint();
        });

        JPanel controls = new JPanel();
        controls.add(clear);

        frame.setLayout(new BorderLayout());
        frame.add(canvas, BorderLayout.CENTER);
        frame.add(controls, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }
}
