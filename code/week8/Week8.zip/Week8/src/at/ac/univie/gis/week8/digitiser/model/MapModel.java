package at.ac.univie.gis.week8.digitiser.model;

import java.util.ArrayList;
import java.util.List;

/**
 * MODEL — the application's state, with no idea that a GUI exists.
 *
 * It keeps track of two things:
 *   - the feature currently being digitised (the "pen"), which is null when
 *     nothing is in progress, and
 *   - the list of features the user has already finished.
 *
 * Everything is stored in world coordinates (via GeoFeature). Because there is no
 * Swing in sight, you could drive this exact same model from a command-line tool
 * or a unit test — which is the whole point of keeping the Model independent
 * (Slide 6).
 */
public class MapModel {

    private final List<GeoFeature> finished = new ArrayList<>();
    private GeoFeature current;                       // null when nothing is in progress
    private FeatureType nextType = FeatureType.ROUTE; // type used when a new feature starts

    /** Choose the type the next started feature will be (the controller sets this). */
    public void setNextType(FeatureType type) {
        this.nextType = type;
    }

    public FeatureType getNextType() {
        return nextType;
    }

    /** The feature currently being drawn, or null. */
    public GeoFeature getCurrent() {
        return current;
    }

    /** All the features the user has finished so far. */
    public List<GeoFeature> getFinished() {
        return finished;
    }

    /**
     * Add a vertex to the current feature. If there is no current feature yet
     * (the user just started, or just finished one), we lazily create one of the
     * chosen type. So the very first click after picking a type begins a feature.
     */
    public void addVertex(double lon, double lat) {
        if (current == null) {
            current = new GeoFeature(nextType);
        }
        current.addVertex(lon, lat);
    }

    /**
     * "Bank" the current feature: move it into the finished list and pick up the
     * pen. We require at least 2 points so a stray single click doesn't create a
     * meaningless feature. Calling this when nothing is in progress is harmless.
     */
    public void finishCurrent() {
        if (current != null && current.size() >= 2) {
            finished.add(current);
        }
        current = null;
    }

    /** Throw away everything — the current pen and every finished feature. */
    public void clearAll() {
        finished.clear();
        current = null;
    }

    /** Replace all finished features, e.g. with the contents of a loaded file. */
    public void replaceFinished(List<GeoFeature> features) {
        finished.clear();
        finished.addAll(features);
        current = null;
    }
}
