package at.ac.univie.gis.week8.sir;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

/**
 * VIEW — draws the grid. It reads the model and paints one coloured square per
 * cell. It owns no data and handles no input.
 *
 * This whole class is provided. The cell colours in colorFor() are a good place
 * to make the simulation your own — change them freely.
 */
public class SirView extends JPanel {

    private static final int CELL = 8; // pixels per grid cell

    private final SirModel model;

    public SirView(SirModel model) {
        this.model = model;
        // Make the panel exactly the size of the grid so it fits snugly next to
        // the chart with no empty border.
        int px = model.getSize() * CELL;
        setPreferredSize(new Dimension(px, px));
        setBackground(Color.WHITE);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int n = model.getSize();
        int[][] grid = model.getGrid();

        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                g.setColor(colorFor(grid[r][c]));
                // column -> x, row -> y
                g.fillRect(c * CELL, r * CELL, CELL, CELL);
            }
        }
    }

    /** Pick the colour for a cell state. Feel free to change these. */
    private Color colorFor(int state) {
        switch (state) {
            case SirModel.S: return new Color(120, 200, 120); // green  = susceptible
            case SirModel.I: return new Color(220, 70, 70);   // red    = infectious
            case SirModel.R: return new Color(150, 160, 180); // grey   = recovered
            default:         return Color.WHITE;              // empty cell
        }
    }
}
