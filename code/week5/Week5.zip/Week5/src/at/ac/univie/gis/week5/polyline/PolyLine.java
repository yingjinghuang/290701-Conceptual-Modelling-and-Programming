package at.ac.univie.gis.week5.polyline;

import java.util.ArrayList;

/**
 * A polyline is an ordered sequence of points connected by straight line segments.
 * The total length is maintained automatically whenever a point is added.
 *
 * This is a good example of why encapsulation matters: by controlling access through
 * the add() method, we ensure that the length is always kept up-to-date.
 */
public class PolyLine {

    private ArrayList<Point> pointlist;
    private double length = 0;

    public PolyLine() {
        pointlist = new ArrayList<Point>();
        // Initialize length to ensure getLength() returns 0 even before any points are added
        computeLength();
    }

    /**
     * Adds a point to the polyline and updates the total length.
     * This is why encapsulation matters: without this method, a user could add points
     * directly to the list and getLength() would return a stale (incorrect) value.
     */
    public boolean add(Point e) {
        if (!pointlist.isEmpty()) {
            // Add the distance from the last point to the new point
            length += pointlist.get(pointlist.size() - 1).distanceTo(e);
        }
        return pointlist.add(e);
    }

    /**
     * Returns the point at the given index.
     */
    public Point get(int index) {
        return pointlist.get(index);
    }

    /**
     * Returns the number of points in the polyline.
     */
    public int size() {
        return pointlist.size();
    }

    /**
     * Recomputes the total length from scratch by summing distances between consecutive points.
     * Normally not needed since add() keeps length up-to-date, but useful after modifications.
     */
    public double computeLength() {
        length = 0; // Reset before summing - the loop adds to length
        for (int i = 0; i < size() - 1; i++) {
            length += Math.sqrt(
                    Math.pow((get(i).getX() - get(i + 1).getX()), 2) +
                    Math.pow((get(i).getY() - get(i + 1).getY()), 2));
        }
        return length;
    }

    /**
     * Returns the current total length of the polyline.
     * Always up-to-date because add() updates it incrementally.
     */
    public double getLength() {
        return length;
    }
}
