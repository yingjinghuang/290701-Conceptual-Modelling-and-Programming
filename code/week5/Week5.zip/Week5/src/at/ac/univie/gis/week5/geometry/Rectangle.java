package at.ac.univie.gis.week5.geometry;

/**
 * Another concrete subclass of Geometry, with its own area formula.
 *
 * --- Week 5 assignment, Task 1 ---
 *
 * Add `implements Drawable, Comparable<Geometry>` to the class line.
 * Then implement:
 *   - `String draw()` from Drawable (one-line text representation,
 *     e.g. "Rectangle('label', w=3.0, h=4.0, area=12.0)")
 *   - `int compareTo(Geometry other)` from Comparable, ordering by area.
 *
 * Keep `extends Geometry` for shared state (the label field).
 * Add interfaces for the new capabilities.
 */
public class Rectangle extends Geometry {

    private double width;
    private double height;

    public Rectangle(String label, double width, double height) {
        super(label);
        this.width = width;
        this.height = height;
    }

    @Override
    public double getArea() {
        return width * height;
    }
}
