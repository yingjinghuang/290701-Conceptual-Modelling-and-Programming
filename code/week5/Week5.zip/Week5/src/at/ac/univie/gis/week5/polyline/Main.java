package at.ac.univie.gis.week5.polyline;

/**
 * Test class for the PolyLine example.
 * Shows how the polyline's length is maintained as points are added.
 */
public class Main {
    public static void main(String[] args) {

        // Create an empty polyline
        PolyLine poly = new PolyLine();
        System.out.println("Empty polyline's length: " + poly.getLength());

        // A 1-point polyline has length 0 (no segments yet)
        // Whether a 1-point polyline should be allowed is a design decision
        poly.add(new Point(5, 5));
        System.out.println("One-point polyline's length: " + poly.getLength());

        // Adding more points creates line segments, increasing the total length
        poly.add(new Point(6, 6));
        poly.add(new Point(8, 7));
        poly.add(new Point(9, 10));

        // add() keeps the length up-to-date; computeLength() recalculates from scratch
        // Both should return the same result
        System.out.println("Polyline's length: " + poly.computeLength());
    }
}
