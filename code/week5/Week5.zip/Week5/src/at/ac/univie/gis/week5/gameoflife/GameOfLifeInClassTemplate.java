package at.ac.univie.gis.week5.gameoflife;

/**
 * Conway's Game of Life - Template for in-class exercise.
 *
 * Rules (to implement in tick()):
 * 1. Any live cell with fewer than 2 live neighbors dies (underpopulation).
 * 2. Any live cell with 2 or 3 live neighbors survives.
 * 3. Any live cell with more than 3 live neighbors dies (overpopulation).
 * 4. Any dead cell with exactly 3 live neighbors becomes alive (reproduction).
 *
 * Students should implement: tick(), neighbours(), and toString().
 */
public class GameOfLifeInClassTemplate {

    // The game grid: true = alive, false = dead
    private boolean[][] game =
            {
                    {false, false, false, false, false, false, false, false, false, false},
                    {false, false, false, true, true, false, false, false, false, false},
                    {false, false, false, true, true, false, false, false, false, false},
                    {false, false, false, false, false, false, false, false, false, false},
                    {false, false, false, false, false, false, false, false, false, false},
                    {false, false, false, true, true, false, true, false, false, false},
                    {false, true, true, true, false, false, false, false, false, false},
                    {false, true, false, false, false, true, false, false, false, false},
                    {false, false, false, false, true, false, false, false, false, false},
                    {false, false, false, false, false, false, false, false, false, false}
            };

    public GameOfLifeInClassTemplate() {
        // Constructor - add initialization code if needed
    }

    /**
     * Advances the simulation by one step, applying the Game of Life rules.
     * IMPORTANT: All cells must be updated simultaneously, so we write to a new array
     * and then replace the old one (otherwise earlier updates would affect later ones).
     */
    public void tick() {
        boolean[][] nextGame = new boolean[game.length][game[0].length];
        // TODO: Apply the four rules using neighbours() to fill nextGame, then set game = nextGame
    }

    /**
     * Counts the number of live neighbors around cell (i, j).
     * Uses Queen's adjacency (8 surrounding cells). Must handle edge cases at grid boundaries.
     */
    public int neighbours(int i, int j) {
        int count = 0;
        // TODO: Check all 8 surrounding cells, incrementing count for each live neighbor
        return count;
    }

    /**
     * Returns a string representation of the grid for console output.
     * For example, use '#' for alive and '.' for dead cells.
     */
    @Override
    public String toString() {
        // TODO: Build a string representation of the grid
        return "";
    }

    /**
     * Main loop: prints the grid, advances one tick, waits, and repeats forever.
     */
    public static void main(String[] args) throws InterruptedException {
        GameOfLifeInClassTemplate game1 = new GameOfLifeInClassTemplate();
        while (true) {
            System.out.println(game1);
            game1.tick();
            Thread.sleep(500); // Pause between frames (increase to 2000ms for debugging)
        }
    }
}
