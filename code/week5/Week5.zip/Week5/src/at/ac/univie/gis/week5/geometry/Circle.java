package at.ac.univie.gis.week5.geometry;

/**
 * A concrete subclass of the abstract Geometry class.
 * Must provide its own getArea() - the compiler enforces this.
 *
 * --- Week 5 assignment, Task 1 ---
 *
 * Add `implements Drawable, Comparable<Geometry>` to the class line.
 * Then implement:
 *   - `String draw()` from Drawable (one-line text representation,
 *     e.g. "Circle('label', r=3.5, area=38.48)")
 *   - `int compareTo(Geometry other)` from Comparable, ordering by area
 *     (Double.compare(this.getArea(), other.getArea()) is the cleanest).
 *
 * Keep `extends Geometry` for shared state (the label field).
 * Add interfaces for the new capabilities.
 */
public class Circle extends Geometry {

    private double radius;

    public Circle(String label, double radius) {
        super(label);
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }
}
