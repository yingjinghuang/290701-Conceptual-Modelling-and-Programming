package at.ac.univie.gis.week5.geometry;

/**
 * Starter for Week 5 Task 1 (Drawable + Comparable).
 *
 * This is the same abstract Geometry from W4's lecture reference package -
 * an abstract base class with a `label` field and an abstract `getArea()`
 * method. Use this as your starting point and add interface support on
 * `Circle` and `Rectangle`.
 *
 * --- Week 5 assignment, Task 1 ---
 *
 * Keep this class as it is - the parent type for shared state and the
 * abstract `getArea()` contract. The work happens in the subclasses:
 *
 *   1. Declare a small `Drawable` interface with one method
 *      `String draw()` that returns a one-line text representation.
 *   2. Make `Circle` and `Rectangle` ALSO implement `Drawable` and
 *      `Comparable<Geometry>` (compareTo orders by area).
 *   3. In a small main, build a `List<Geometry>` mixing circles and
 *      rectangles, sort with `Collections.sort(list)`, print each via
 *      `draw()`.
 */
public abstract class Geometry {

    private String label;

    public Geometry(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    /**
     * Abstract method - no body, just a contract.
     * Each subclass fills this in with its own area formula.
     */
    public abstract double getArea();

    /**
     * A concrete method on an abstract class is allowed.
     * It can call the abstract method - the call resolves to the
     * subclass implementation at runtime (dynamic dispatch).
     */
    public String describe() {
        return label + " has area " + getArea();
    }
}
